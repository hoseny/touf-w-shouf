(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888,1747,6344];
exports.modules = {

/***/ 2020:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function useIsAuthPage() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const { 0: isAuthPage , 1: setIsAuthPage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const authPages = [
            "/login",
            "/signup"
        ];
        setIsAuthPage(authPages.includes(router.pathname));
    }, [
        router.pathname
    ]);
    return isAuthPage;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useIsAuthPage);


/***/ }),

/***/ 9646:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Ar_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9863);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__]);
i18next__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const resources = {
    ar: {
        translation: {
            ..._Ar_json__WEBPACK_IMPORTED_MODULE_2__
        }
    }
};
i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next).init({
    resources,
    lng: "en",
    interpolation: {
        escapeValue: false
    }
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (i18n)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7034:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8541);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(345);
/* harmony import */ var _hooks_auth_useIsAuthPages__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2020);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_3__]);
_header__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            (0,_hooks_auth_useIsAuthPages__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)() ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                        sx: {
                            height: "42px"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                        children: children
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                        sx: {
                            height: "149px"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default()), {
                        children: children
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/Container"
var Container_ = __webpack_require__(4475);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);
// EXTERNAL MODULE: external "@mui/material/Stack"
var Stack_ = __webpack_require__(8742);
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/TextField"
var TextField_ = __webpack_require__(6042);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(3819);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "@mui/material/Divider"
var Divider_ = __webpack_require__(3646);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_);
// EXTERNAL MODULE: external "@mui/material/Link"
var Link_ = __webpack_require__(5246);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: external "@mui/icons-material/FacebookSharp"
const FacebookSharp_namespaceObject = require("@mui/icons-material/FacebookSharp");
var FacebookSharp_default = /*#__PURE__*/__webpack_require__.n(FacebookSharp_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Instagram"
const Instagram_namespaceObject = require("@mui/icons-material/Instagram");
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_namespaceObject);
// EXTERNAL MODULE: external "@mui/icons-material/Twitter"
var Twitter_ = __webpack_require__(5631);
var Twitter_default = /*#__PURE__*/__webpack_require__.n(Twitter_);
;// CONCATENATED MODULE: ./layout/footer/index.tsx
















const Index = ()=>{
    const { t  } = (0,external_react_i18next_.useTranslation)();
    return /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
        sx: {
            flexGrow: 1,
            backgroundColor: "body.main",
            width: "100%",
            color: "body.light",
            py: 4
        },
        component: "footer",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                    sx: {
                        mb: 4
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        container: true,
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                item: true,
                                xs: 12,
                                sm: 6,
                                md: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle1",
                                            children: t("About Us")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Contact Us")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Cities")
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                item: true,
                                xs: 12,
                                sm: 6,
                                md: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle1",
                                            children: t("Information")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("FAQs")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Vision")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Goals")
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                item: true,
                                xs: 12,
                                sm: 6,
                                md: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle1",
                                            children: t("Related links")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Ministry of Tourism")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Ministry of Antiquities")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Ministry of Environment")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Ministry of Education")
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        sx: {
                                            mb: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "",
                                            children: t("Egyptian Government Portal")
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                item: true,
                                xs: 12,
                                sm: 6,
                                md: 3,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                    direction: "column",
                                    justifyContent: "space-between",
                                    sx: {
                                        height: "100%"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                                    sx: {
                                                        mb: 2
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle1",
                                                        children: t("Subscribe to our newsletter")
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            id: "outlined-basic",
                                                            variant: "outlined",
                                                            fullWidth: true,
                                                            placeholder: t("Search"),
                                                            sx: {
                                                                backgroundColor: "body.light",
                                                                borderRadius: "5px 0 0 5px"
                                                            }
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                            variant: "contained",
                                                            sx: {
                                                                borderRadius: "0 5px 5px 0",
                                                                ml: "-5px",
                                                                py: 2
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                variant: "button",
                                                                children: t("Send")
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                                    sx: {
                                                        mb: 2
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle1",
                                                        children: t("Social media")
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 2,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            href: "#",
                                                            target: "_blank",
                                                            underline: "none",
                                                            sx: {
                                                                color: "body.light"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((FacebookSharp_default()), {})
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            href: "#",
                                                            target: "_blank",
                                                            underline: "none",
                                                            sx: {
                                                                color: "body.light"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {})
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            href: "#",
                                                            target: "_blank",
                                                            underline: "none",
                                                            sx: {
                                                                color: "body.light"
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Twitter_default()), {})
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                    sx: {
                        borderColor: "gray.main",
                        my: 2
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                    direction: {
                        xs: "column",
                        sm: "row"
                    },
                    alignItems: "center",
                    justifyContent: "space-between",
                    spacing: {
                        xs: 2,
                        sm: 0
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "caption",
                            children: t("Touf w Shof. 2024 - All Rights Reserved")
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "caption",
                            children: t("Created by ITD")
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const footer = (Index);


/***/ }),

/***/ 8682:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header_Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/useScrollTrigger"
var useScrollTrigger_ = __webpack_require__(4156);
var useScrollTrigger_default = /*#__PURE__*/__webpack_require__.n(useScrollTrigger_);
// EXTERNAL MODULE: external "@mui/material/AppBar"
var AppBar_ = __webpack_require__(3882);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);
// EXTERNAL MODULE: external "@mui/material/Container"
var Container_ = __webpack_require__(4475);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);
// EXTERNAL MODULE: external "@mui/material/Stack"
var Stack_ = __webpack_require__(8742);
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(7934);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
;// CONCATENATED MODULE: external "@mui/material/Toolbar"
const Toolbar_namespaceObject = require("@mui/material/Toolbar");
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "@mui/icons-material/ShoppingBag"
const ShoppingBag_namespaceObject = require("@mui/icons-material/ShoppingBag");
var ShoppingBag_default = /*#__PURE__*/__webpack_require__.n(ShoppingBag_namespaceObject);
;// CONCATENATED MODULE: ./assets/images/logo_en.webp
/* harmony default export */ const logo_en = ({"src":"/_next/static/media/logo_en.9b900680.webp","height":75,"width":155,"blurDataURL":"data:image/webp;base64,UklGRpoAAABXRUJQVlA4WAoAAAAQAAAABwAAAwAAQUxQSCEAAAAAr/+VAAAAAAC8v6ojPS00PCKFJhAzJS8kEo0IAAAAAAAAVlA4IFIAAADwAQCdASoIAAQAAkA4JZgCdDKcgVkhL2AA9rwcXhY9DyDulKFH+0e7Bi1BT9Rx/mUNmtOvrieHorKTViMVtf5uvDjKixuf3//JyJ0/KWf4K4AA"});
;// CONCATENATED MODULE: ./assets/images/misr-tour.jpg
/* harmony default export */ const misr_tour = ({"src":"/_next/static/media/misr-tour.a2f5183c.jpg","height":279,"width":850,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAKiLP//EABkQAQACAwAAAAAAAAAAAAAAAAECEgAhMv/aAAgBAQABPwChChFkaHpz/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "@mui/icons-material/Menu"
const Menu_namespaceObject = require("@mui/icons-material/Menu");
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Close"
const Close_namespaceObject = require("@mui/icons-material/Close");
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Drawer"
const Drawer_namespaceObject = require("@mui/material/Drawer");
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer_namespaceObject);
;// CONCATENATED MODULE: ./layout/header/Navbar.tsx




















const Navbar = (props)=>{
    const { window  } = props;
    const { t  } = (0,external_react_i18next_.useTranslation)();
    const router = (0,router_.useRouter)();
    const trigger = useScrollTrigger_default()({
        disableHysteresis: true,
        threshold: 0,
        target: window ? window() : undefined
    });
    const { 0: drawerOpen , 1: setDrawerOpen  } = (0,external_react_.useState)(false);
    const toggleDrawer = (open)=>(event)=>{
            if (event.type === "keydown" && (event.key === "Tab" || event.key === "Shift")) {
                return;
            }
            setDrawerOpen(open);
        };
    return /*#__PURE__*/ jsx_runtime_.jsx(ElevationScroll, {
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((AppBar_default()), {
                    sx: {
                        top: trigger ? 0 : "49px",
                        backgroundColor: "body.light",
                        color: "body.main"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Toolbar_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                            maxWidth: "lg",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                container: true,
                                spacing: 3,
                                alignItems: "center",
                                justifyContent: "space-between",
                                padding: "10px",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                        item: true,
                                        xs: 5,
                                        sm: 2,
                                        sx: {
                                            textAlign: "left"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                            onClick: ()=>router.push("/"),
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: misr_tour,
                                                alt: "logo-left",
                                                priority: true,
                                                layout: "intrinsic"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                                        item: true,
                                        xs: 7,
                                        sm: 8,
                                        sx: {
                                            textAlign: "right"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                                direction: "row",
                                                spacing: 4,
                                                sx: {
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                    display: {
                                                        xs: "none",
                                                        sm: "flex"
                                                    }
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/",
                                                        children: t("Home")
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/myReservation",
                                                        children: t("My Reservations")
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/ContactUs",
                                                        children: t("Contact Us")
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/Suggestion",
                                                        children: t("Complaint and Suggestion")
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Stack_default()), {
                                                        direction: "row",
                                                        alignItems: "center",
                                                        spacing: 1.5,
                                                        justifyContent: "end",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                            sx: {
                                                                color: "body.main"
                                                            },
                                                            onClick: ()=>router.push("/wishlist"),
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((ShoppingBag_default()), {})
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                sx: {
                                                    display: {
                                                        xs: "inline-flex",
                                                        sm: "none"
                                                    },
                                                    color: "body.main"
                                                },
                                                onClick: toggleDrawer(true),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {})
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                                        item: true,
                                        xs: 2,
                                        sm: 2,
                                        sx: {
                                            textAlign: "right",
                                            display: {
                                                xs: "none",
                                                sm: "block"
                                            }
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                            onClick: ()=>router.push("/"),
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: logo_en,
                                                alt: "logo-right",
                                                priority: true,
                                                layout: "intrinsic"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
                    anchor: "right",
                    open: drawerOpen,
                    onClose: toggleDrawer(false),
                    sx: {
                        "& .MuiDrawer-paper": {
                            width: 250,
                            padding: 2
                        }
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: toggleDrawer(false),
                                sx: {
                                    color: "body.main",
                                    mb: 2
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Close_default()), {})
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                                direction: "column",
                                spacing: 2,
                                sx: {
                                    textAlign: "left"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        onClick: ()=>{
                                            router.push("/");
                                            setDrawerOpen(false);
                                        },
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        children: t("Home")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        onClick: ()=>{
                                            router.push("/myReservation");
                                            setDrawerOpen(false);
                                        },
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        children: t("My Reservations")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        onClick: ()=>{
                                            router.push("/ContactUs");
                                            setDrawerOpen(false);
                                        },
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        children: t("Contact Us")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                        onClick: ()=>{
                                            router.push("/Suggestion");
                                            setDrawerOpen(false);
                                        },
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        children: t("Complaint and Suggestion")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        sx: {
                                            color: "body.main",
                                            alignSelf: "flex-start"
                                        },
                                        onClick: ()=>{
                                            router.push("/wishlist");
                                            setDrawerOpen(false);
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((ShoppingBag_default()), {})
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const header_Navbar = (Navbar);
function ElevationScroll(props) {
    const { children , window  } = props;
    const trigger = useScrollTrigger_default()({
        disableHysteresis: true,
        threshold: 0,
        target: window ? window() : undefined
    });
    return /*#__PURE__*/ external_react_default().cloneElement(children, {
        elevation: trigger ? 4 : 1,
        top: trigger ? "0px" : "top: 49px"
    });
}


/***/ }),

/***/ 7731:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3882);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4475);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Zoom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1528);
/* harmony import */ var _mui_material_Zoom__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Zoom__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4156);
/* harmony import */ var _mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_Call__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2081);
/* harmony import */ var _mui_icons_material_Call__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Call__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _hooks_useStore__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7819);
/* harmony import */ var _store_languageSlice__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4366);
/* harmony import */ var _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8173);
/* harmony import */ var _hooks_auth_useIsAuthPages__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2020);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_languageSlice__WEBPACK_IMPORTED_MODULE_14__]);
_store_languageSlice__WEBPACK_IMPORTED_MODULE_14__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

















const Topbar = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_12__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const language = (0,_hooks_useStore__WEBPACK_IMPORTED_MODULE_13__/* .useAppSelector */ .C)(_store_languageSlice__WEBPACK_IMPORTED_MODULE_14__/* .getLanguage */ .G3);
    const dispatch = (0,_hooks_useStore__WEBPACK_IMPORTED_MODULE_13__/* .useAppDispatch */ .T)();
    const changeLanguage = ()=>{
        switch(language){
            case "en":
                dispatch((0,_store_languageSlice__WEBPACK_IMPORTED_MODULE_14__/* .toggleLanguage */ .v7)("ar"));
                _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_15__/* .ClientStorage.set */ .j.set("language", "ar");
                break;
            case "ar":
                dispatch((0,_store_languageSlice__WEBPACK_IMPORTED_MODULE_14__/* .toggleLanguage */ .v7)("en"));
                _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_15__/* .ClientStorage.set */ .j.set("language", "en");
                break;
        }
    };
    const { 0: isAuthenticated , 1: setIsAuthenticated  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { 0: username , 1: setUsername  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        const token = localStorage.getItem("token");
        const savedUsername = localStorage.getItem("NAME");
        setIsAuthenticated(!!token);
        setUsername(savedUsername);
    }, [
        router.pathname
    ]);
    const handleLogout = ()=>{
        localStorage.clear();
        setIsAuthenticated(false);
        router.push("/login");
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HideOnScroll, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_1___default()), {
            sx: {
                flexGrow: 1,
                backgroundColor: "body.main",
                color: "body.light",
                boxShadow: "unset !important"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Container__WEBPACK_IMPORTED_MODULE_3___default()), {
                maxWidth: "lg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                    container: true,
                    spacing: 2,
                    justifyContent: "space-between",
                    alignItems: "center",
                    sx: {
                        py: 0.5
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                            item: true,
                            xs: 6,
                            sx: {
                                pl: "unset !important"
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                direction: "row",
                                alignItems: "center",
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Call__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        sx: {
                                            fontSize: {
                                                xs: "20px",
                                                sm: "30px"
                                            }
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        variant: "h3",
                                        sx: {
                                            fontSize: {
                                                xs: "20px",
                                                sm: "30px"
                                            }
                                        },
                                        children: "19341"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                            item: true,
                            xs: 6,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                direction: "row",
                                alignItems: "center",
                                spacing: 1.5,
                                justifyContent: "end",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "text",
                                        onClick: changeLanguage,
                                        sx: {
                                            fontFamily: "Cairo , sans-serif",
                                            color: "body.light",
                                            fontWeight: 500
                                        },
                                        children: t("العربية")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        variant: "body1",
                                        sx: {
                                            color: "body.light",
                                            fontSize: {
                                                xs: "12px",
                                                sm: "16px"
                                            }
                                        },
                                        children: username ? `${t("Welcome")}, ${username}` : ""
                                    }),
                                    isAuthenticated ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "contained",
                                        onClick: handleLogout,
                                        children: t("Logout")
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "contained",
                                        onClick: ()=>router.push("/login"),
                                        children: t("Sign in")
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Topbar);
function HideOnScroll(props) {
    const { children , window  } = props;
    const trigger = _mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_8___default()({
        threshold: 0,
        target: window ? window() : undefined
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Zoom__WEBPACK_IMPORTED_MODULE_7___default()), {
        appear: false,
        in: (0,_hooks_auth_useIsAuthPages__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)() ? true : !trigger,
        children: children
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8541:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8682);
/* harmony import */ var _Topbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7731);
/* harmony import */ var _hooks_auth_useIsAuthPages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2020);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Topbar__WEBPACK_IMPORTED_MODULE_3__]);
_Topbar__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Index = ()=>{
    const isAuthPage = (0,_hooks_auth_useIsAuthPages__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Topbar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            !isAuthPage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5656:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _theme_theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(137);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6073);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8890);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _i18n_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9646);
/* harmony import */ var _layout_Layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7034);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_theme_theme__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_3__, _i18n_i18n__WEBPACK_IMPORTED_MODULE_5__, _layout_Layout__WEBPACK_IMPORTED_MODULE_6__]);
([_theme_theme__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_3__, _i18n_i18n__WEBPACK_IMPORTED_MODULE_5__, _layout_Layout__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_2__.Provider, {
        store: _store_store__WEBPACK_IMPORTED_MODULE_3__/* .store */ .h,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_theme_theme__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_Layout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_4___default()), {
                        color: "#E07026",
                        height: 3,
                        showOnShallow: true
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ FetchLanguageApi)
/* harmony export */ });
/* unused harmony export useGetLanguageQuery */
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchLanguageApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "LanguageData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getLanguage: builder.query({
                query: ()=>`/language/`
            })
        })
});
const { useGetLanguageQuery  } = FetchLanguageApi;


/***/ }),

/***/ 6688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ FetchNationalityApi)
/* harmony export */ });
/* unused harmony export useGetNationalityQuery */
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchNationalityApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "NationalityData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/programes/"
    }),
    endpoints: (builder)=>({
            getNationality: builder.query({
                query: ()=>"AllNationality"
            })
        })
});
const { useGetNationalityQuery  } = FetchNationalityApi;


/***/ }),

/***/ 8535:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ FetchForgetPassDataApi),
/* harmony export */   "V": () => (/* binding */ useLazyForgetPassQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchForgetPassDataApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "ForgetPass",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            forgetPass: builder.query({
                query: ({ Email  })=>`forgetPassword/${Email}`
            })
        })
});
const { useLazyForgetPassQuery  } = FetchForgetPassDataApi;


/***/ }),

/***/ 4193:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ ResetPasswordApi),
/* harmony export */   "g": () => (/* binding */ useResetPasswordMutation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const ResetPasswordApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "ResetPassword",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            ResetPassword: builder.mutation({
                query: ({ V_OTP , Email , TransNo , pass  })=>({
                        url: `forgetPassword/${Email}`,
                        method: "PUT",
                        params: {
                            Email,
                            V_OTP,
                            TransNo,
                            pass
                        }
                    })
            })
        })
});
const { useResetPasswordMutation  } = ResetPasswordApi;


/***/ }),

/***/ 3570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ VerifyPasswordApi),
/* harmony export */   "o": () => (/* binding */ useVerifyPasswordMutation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const VerifyPasswordApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "VerifyPassword",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            VerifyPassword: builder.mutation({
                query: ({ V_OTP , Email  })=>({
                        url: `forgetPassword/${Email}`,
                        method: "POST",
                        body: {
                            V_OTP
                        }
                    })
            })
        })
});
const { useVerifyPasswordMutation  } = VerifyPasswordApi;


/***/ }),

/***/ 1670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ useAddReviewMutation),
/* harmony export */   "t": () => (/* binding */ AddReviewApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const AddReviewApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "AddReview",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            addReview: builder.mutation({
                query: ({ code , programyear , cust , rate , review  })=>({
                        url: `programReview/${code}/${programyear}`,
                        method: "POST",
                        body: {
                            cust,
                            rate,
                            review
                        }
                    })
            })
        })
});
const { useAddReviewMutation  } = AddReviewApi;


/***/ }),

/***/ 5516:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useGetDayUseQuery),
/* harmony export */   "d": () => (/* binding */ FetchDayUseApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchDayUseApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "ProductsDayUse",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getDayUse: builder.query({
                query: ()=>"/ProgramArabic"
            })
        })
});
const { useGetDayUseQuery  } = FetchDayUseApi;


/***/ }),

/***/ 4147:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ FetchProductApi)
/* harmony export */ });
/* unused harmony export useGetProductQuery */
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchProductApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "ProductsData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getProduct: builder.query({
                query: ()=>"/onlyCurrent/1"
            })
        })
});
const { useGetProductQuery  } = FetchProductApi;


/***/ }),

/***/ 7685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ FetchPolicyArApi)
/* harmony export */ });
/* unused harmony export useGetPolicyArQuery */
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPolicyArApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PolicyArData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getPolicyAr: builder.query({
                query: ({ code , programyear  })=>`/programpolicy/${code}/${programyear}/Cancel`
            })
        })
});
const { useGetPolicyArQuery  } = FetchPolicyArApi;


/***/ }),

/***/ 7986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useGetPaidReservationQuery),
/* harmony export */   "U": () => (/* binding */ FetchPaidReservation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPaidReservation = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PaidReservationData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `https://app.misrtravelco.net:4444/ords/invoice/public/`
    }),
    endpoints: (builder)=>({
            getPaidReservation: builder.query({
                query: (id)=>`GetPayment?CustomerID=${id}`
            })
        })
});
const { useGetPaidReservationQuery  } = FetchPaidReservation;


/***/ }),

/***/ 9958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useGetPaymentQuery),
/* harmony export */   "h": () => (/* binding */ FetchPaymentApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPaymentApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PaymentData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getPayment: builder.query({
                query: ({ ref , sp  })=>`/payment/${ref}/${sp}`
            })
        })
});
const { useGetPaymentQuery  } = FetchPaymentApi;


/***/ }),

/***/ 6073:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _languageSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4366);
/* harmony import */ var _Products_GetProductsApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4147);
/* harmony import */ var _Register_RegisterApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4868);
/* harmony import */ var _Register_LoginApi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1262);
/* harmony import */ var _Products_FetchImagesApi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3361);
/* harmony import */ var _Products_FetchDetailsApi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(612);
/* harmony import */ var _Products_FetchReviewApi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9225);
/* harmony import */ var _Products_FetchSupplementApi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8288);
/* harmony import */ var _Products_FetchTourIncludingApi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2688);
/* harmony import */ var _Products_FetchPolicyApi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5872);
/* harmony import */ var _Register_VerifyEmailApi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8019);
/* harmony import */ var _Products_AddReviewApi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1670);
/* harmony import */ var _Register_userSlice__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6496);
/* harmony import */ var _Products_FetchProgramGroupsApi__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7921);
/* harmony import */ var _Products_FetchGroupPriceApi__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5295);
/* harmony import */ var _Products_FetchExtraApi__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4499);
/* harmony import */ var _Reservation_AddReservationApi__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4189);
/* harmony import */ var _Reservation_AddExtraApi__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6885);
/* harmony import */ var _Reservation_AddReservationDetailsApi__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6485);
/* harmony import */ var _Reservation_FetchPaymentApi__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9958);
/* harmony import */ var _ForgetPassword_FetchForgetPassDataApi__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8535);
/* harmony import */ var _ForgetPassword_VerifyPasswordApi__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3570);
/* harmony import */ var _ForgetPassword_ResetPasswordApi__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4193);
/* harmony import */ var _Filter_FetchNationalityApi__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6688);
/* harmony import */ var _wishlistSlice__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6719);
/* harmony import */ var _FetchLanguageApi__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(5553);
/* harmony import */ var _Products_FetchDayUseApi__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(5516);
/* harmony import */ var _Products_FetchPackagesEnApi__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(1234);
/* harmony import */ var _Products_FetchPackagesArApi__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(5721);
/* harmony import */ var _Products_ProgramDetailsAR_FetchDetailsARApi__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(3902);
/* harmony import */ var _Products_ProgramDetailsAR_FetchTourIncludingArApi__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(5294);
/* harmony import */ var _Products_ProgramDetailsAR_FetchPolicyArApi__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(7685);
/* harmony import */ var _Products_ProgramDetailsAR_FetchTourExcludingArApi__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(384);
/* harmony import */ var _Filter_FetchCountryEnApi__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(7356);
/* harmony import */ var _Filter_FetchCountryArApi__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(90);
/* harmony import */ var _Filter_FetchTourTypeApi__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(8808);
/* harmony import */ var _Reservation_FetchPaidReservation__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(7986);
/* harmony import */ var _Products_FetchSupplementArApi__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(3884);
/* harmony import */ var _Filter_FetchCityEnApi__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(2009);
/* harmony import */ var _Filter_FetchCityArApi__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(8631);
/* harmony import */ var _Filter_FetchTourTypeArApi__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(9613);
/* harmony import */ var _Reservation_FetchUnPaidReservation__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(2232);
/* harmony import */ var _Reservation_FetchInvoiceById__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(4504);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_languageSlice__WEBPACK_IMPORTED_MODULE_1__]);
_languageSlice__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












































const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        language: _languageSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
        user: _Register_userSlice__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .ZP,
        wishlist: _wishlistSlice__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .ZP,
        [_Products_GetProductsApi__WEBPACK_IMPORTED_MODULE_2__/* .FetchProductApi.reducerPath */ .I.reducerPath]: _Products_GetProductsApi__WEBPACK_IMPORTED_MODULE_2__/* .FetchProductApi.reducer */ .I.reducer,
        [_Products_FetchDayUseApi__WEBPACK_IMPORTED_MODULE_27__/* .FetchDayUseApi.reducerPath */ .d.reducerPath]: _Products_FetchDayUseApi__WEBPACK_IMPORTED_MODULE_27__/* .FetchDayUseApi.reducer */ .d.reducer,
        [_Register_RegisterApi__WEBPACK_IMPORTED_MODULE_3__/* .RegisterApi.reducerPath */ .p.reducerPath]: _Register_RegisterApi__WEBPACK_IMPORTED_MODULE_3__/* .RegisterApi.reducer */ .p.reducer,
        [_Register_LoginApi__WEBPACK_IMPORTED_MODULE_4__/* .LoginApi.reducerPath */ .I.reducerPath]: _Register_LoginApi__WEBPACK_IMPORTED_MODULE_4__/* .LoginApi.reducer */ .I.reducer,
        [_Products_FetchImagesApi__WEBPACK_IMPORTED_MODULE_5__/* .FetchImagesApi.reducerPath */ .b.reducerPath]: _Products_FetchImagesApi__WEBPACK_IMPORTED_MODULE_5__/* .FetchImagesApi.reducer */ .b.reducer,
        [_Products_FetchDetailsApi__WEBPACK_IMPORTED_MODULE_6__/* .FetchDetailsApi.reducerPath */ .k.reducerPath]: _Products_FetchDetailsApi__WEBPACK_IMPORTED_MODULE_6__/* .FetchDetailsApi.reducer */ .k.reducer,
        [_Products_FetchReviewApi__WEBPACK_IMPORTED_MODULE_7__/* .FetchReviewApi.reducerPath */ .i.reducerPath]: _Products_FetchReviewApi__WEBPACK_IMPORTED_MODULE_7__/* .FetchReviewApi.reducer */ .i.reducer,
        [_Products_FetchSupplementApi__WEBPACK_IMPORTED_MODULE_8__/* .FetchSupplementApi.reducerPath */ .a.reducerPath]: _Products_FetchSupplementApi__WEBPACK_IMPORTED_MODULE_8__/* .FetchSupplementApi.reducer */ .a.reducer,
        [_Products_FetchTourIncludingApi__WEBPACK_IMPORTED_MODULE_9__/* .FetchTourIncludingApi.reducerPath */ .V.reducerPath]: _Products_FetchTourIncludingApi__WEBPACK_IMPORTED_MODULE_9__/* .FetchTourIncludingApi.reducer */ .V.reducer,
        [_Products_FetchPolicyApi__WEBPACK_IMPORTED_MODULE_10__/* .FetchPolicyApi.reducerPath */ .B.reducerPath]: _Products_FetchPolicyApi__WEBPACK_IMPORTED_MODULE_10__/* .FetchPolicyApi.reducer */ .B.reducer,
        [_Register_VerifyEmailApi__WEBPACK_IMPORTED_MODULE_11__/* .VerifyEmailApi.reducerPath */ .p.reducerPath]: _Register_VerifyEmailApi__WEBPACK_IMPORTED_MODULE_11__/* .VerifyEmailApi.reducer */ .p.reducer,
        [_Products_AddReviewApi__WEBPACK_IMPORTED_MODULE_12__/* .AddReviewApi.reducerPath */ .t.reducerPath]: _Products_AddReviewApi__WEBPACK_IMPORTED_MODULE_12__/* .AddReviewApi.reducer */ .t.reducer,
        [_Products_FetchProgramGroupsApi__WEBPACK_IMPORTED_MODULE_14__/* .FetchProgramGroupsApi.reducerPath */ .C.reducerPath]: _Products_FetchProgramGroupsApi__WEBPACK_IMPORTED_MODULE_14__/* .FetchProgramGroupsApi.reducer */ .C.reducer,
        [_Products_FetchGroupPriceApi__WEBPACK_IMPORTED_MODULE_15__/* .FetchGroupPriceApi.reducerPath */ .V.reducerPath]: _Products_FetchGroupPriceApi__WEBPACK_IMPORTED_MODULE_15__/* .FetchGroupPriceApi.reducer */ .V.reducer,
        [_Products_FetchExtraApi__WEBPACK_IMPORTED_MODULE_16__/* .FetchExtraApi.reducerPath */ .e.reducerPath]: _Products_FetchExtraApi__WEBPACK_IMPORTED_MODULE_16__/* .FetchExtraApi.reducer */ .e.reducer,
        [_Reservation_AddReservationApi__WEBPACK_IMPORTED_MODULE_17__/* .AddReservationApi.reducerPath */ .$.reducerPath]: _Reservation_AddReservationApi__WEBPACK_IMPORTED_MODULE_17__/* .AddReservationApi.reducer */ .$.reducer,
        [_Reservation_AddExtraApi__WEBPACK_IMPORTED_MODULE_18__/* .AddExtraApi.reducerPath */ .K.reducerPath]: _Reservation_AddExtraApi__WEBPACK_IMPORTED_MODULE_18__/* .AddExtraApi.reducer */ .K.reducer,
        [_Reservation_AddReservationDetailsApi__WEBPACK_IMPORTED_MODULE_19__/* .AddReservationDetailsApi.reducerPath */ .E.reducerPath]: _Reservation_AddReservationDetailsApi__WEBPACK_IMPORTED_MODULE_19__/* .AddReservationDetailsApi.reducer */ .E.reducer,
        [_Reservation_FetchPaymentApi__WEBPACK_IMPORTED_MODULE_20__/* .FetchPaymentApi.reducerPath */ .h.reducerPath]: _Reservation_FetchPaymentApi__WEBPACK_IMPORTED_MODULE_20__/* .FetchPaymentApi.reducer */ .h.reducer,
        [_ForgetPassword_FetchForgetPassDataApi__WEBPACK_IMPORTED_MODULE_21__/* .FetchForgetPassDataApi.reducerPath */ .T.reducerPath]: _ForgetPassword_FetchForgetPassDataApi__WEBPACK_IMPORTED_MODULE_21__/* .FetchForgetPassDataApi.reducer */ .T.reducer,
        [_ForgetPassword_ResetPasswordApi__WEBPACK_IMPORTED_MODULE_23__/* .ResetPasswordApi.reducerPath */ .P.reducerPath]: _ForgetPassword_ResetPasswordApi__WEBPACK_IMPORTED_MODULE_23__/* .ResetPasswordApi.reducer */ .P.reducer,
        [_ForgetPassword_VerifyPasswordApi__WEBPACK_IMPORTED_MODULE_22__/* .VerifyPasswordApi.reducerPath */ .I.reducerPath]: _ForgetPassword_VerifyPasswordApi__WEBPACK_IMPORTED_MODULE_22__/* .VerifyPasswordApi.reducer */ .I.reducer,
        [_Filter_FetchNationalityApi__WEBPACK_IMPORTED_MODULE_24__/* .FetchNationalityApi.reducerPath */ .r.reducerPath]: _Filter_FetchNationalityApi__WEBPACK_IMPORTED_MODULE_24__/* .FetchNationalityApi.reducer */ .r.reducer,
        [_FetchLanguageApi__WEBPACK_IMPORTED_MODULE_26__/* .FetchLanguageApi.reducerPath */ .t.reducerPath]: _FetchLanguageApi__WEBPACK_IMPORTED_MODULE_26__/* .FetchLanguageApi.reducer */ .t.reducer,
        [_Products_FetchPackagesArApi__WEBPACK_IMPORTED_MODULE_29__/* .FetchPackagesArApi.reducerPath */ .N.reducerPath]: _Products_FetchPackagesArApi__WEBPACK_IMPORTED_MODULE_29__/* .FetchPackagesArApi.reducer */ .N.reducer,
        [_Products_FetchPackagesEnApi__WEBPACK_IMPORTED_MODULE_28__/* .FetchPackagesEnApi.reducerPath */ .M.reducerPath]: _Products_FetchPackagesEnApi__WEBPACK_IMPORTED_MODULE_28__/* .FetchPackagesEnApi.reducer */ .M.reducer,
        [_Products_ProgramDetailsAR_FetchDetailsARApi__WEBPACK_IMPORTED_MODULE_30__/* .FetchDetailsARApi.reducerPath */ .U.reducerPath]: _Products_ProgramDetailsAR_FetchDetailsARApi__WEBPACK_IMPORTED_MODULE_30__/* .FetchDetailsARApi.reducer */ .U.reducer,
        [_Products_ProgramDetailsAR_FetchTourIncludingArApi__WEBPACK_IMPORTED_MODULE_31__/* .FetchTourIncludingArApi.reducerPath */ .s.reducerPath]: _Products_ProgramDetailsAR_FetchTourIncludingArApi__WEBPACK_IMPORTED_MODULE_31__/* .FetchTourIncludingArApi.reducer */ .s.reducer,
        [_Products_ProgramDetailsAR_FetchPolicyArApi__WEBPACK_IMPORTED_MODULE_32__/* .FetchPolicyArApi.reducerPath */ .z.reducerPath]: _Products_ProgramDetailsAR_FetchPolicyArApi__WEBPACK_IMPORTED_MODULE_32__/* .FetchPolicyArApi.reducer */ .z.reducer,
        [_Products_ProgramDetailsAR_FetchTourExcludingArApi__WEBPACK_IMPORTED_MODULE_33__/* .FetchTourExcludingArApi.reducerPath */ .N.reducerPath]: _Products_ProgramDetailsAR_FetchTourExcludingArApi__WEBPACK_IMPORTED_MODULE_33__/* .FetchTourExcludingArApi.reducer */ .N.reducer,
        [_Filter_FetchCountryEnApi__WEBPACK_IMPORTED_MODULE_34__/* .FetchCountryEnApi.reducerPath */ .w.reducerPath]: _Filter_FetchCountryEnApi__WEBPACK_IMPORTED_MODULE_34__/* .FetchCountryEnApi.reducer */ .w.reducer,
        [_Filter_FetchTourTypeApi__WEBPACK_IMPORTED_MODULE_36__/* .FetchTourTypeApi.reducerPath */ .V.reducerPath]: _Filter_FetchTourTypeApi__WEBPACK_IMPORTED_MODULE_36__/* .FetchTourTypeApi.reducer */ .V.reducer,
        [_Filter_FetchCountryArApi__WEBPACK_IMPORTED_MODULE_35__/* .FetchCountryArApi.reducerPath */ .M.reducerPath]: _Filter_FetchCountryArApi__WEBPACK_IMPORTED_MODULE_35__/* .FetchCountryArApi.reducer */ .M.reducer,
        [_Reservation_FetchPaidReservation__WEBPACK_IMPORTED_MODULE_37__/* .FetchPaidReservation.reducerPath */ .U.reducerPath]: _Reservation_FetchPaidReservation__WEBPACK_IMPORTED_MODULE_37__/* .FetchPaidReservation.reducer */ .U.reducer,
        [_Reservation_FetchUnPaidReservation__WEBPACK_IMPORTED_MODULE_42__/* .FetchUnPaidReservation.reducerPath */ .J.reducerPath]: _Reservation_FetchUnPaidReservation__WEBPACK_IMPORTED_MODULE_42__/* .FetchUnPaidReservation.reducer */ .J.reducer,
        [_Products_FetchSupplementArApi__WEBPACK_IMPORTED_MODULE_38__/* .FetchSupplementArApi.reducerPath */ .V.reducerPath]: _Products_FetchSupplementArApi__WEBPACK_IMPORTED_MODULE_38__/* .FetchSupplementArApi.reducer */ .V.reducer,
        [_Filter_FetchCityEnApi__WEBPACK_IMPORTED_MODULE_39__/* .FetchCityEnApi.reducerPath */ .o.reducerPath]: _Filter_FetchCityEnApi__WEBPACK_IMPORTED_MODULE_39__/* .FetchCityEnApi.reducer */ .o.reducer,
        [_Filter_FetchCityArApi__WEBPACK_IMPORTED_MODULE_40__/* .FetchCityArApi.reducerPath */ .o.reducerPath]: _Filter_FetchCityArApi__WEBPACK_IMPORTED_MODULE_40__/* .FetchCityArApi.reducer */ .o.reducer,
        [_Filter_FetchTourTypeArApi__WEBPACK_IMPORTED_MODULE_41__/* .FetchTourTypeArApi.reducerPath */ .R.reducerPath]: _Filter_FetchTourTypeArApi__WEBPACK_IMPORTED_MODULE_41__/* .FetchTourTypeArApi.reducer */ .R.reducer,
        [_Reservation_FetchInvoiceById__WEBPACK_IMPORTED_MODULE_43__/* .FetchInvoiceById.reducerPath */ .Y.reducerPath]: _Reservation_FetchInvoiceById__WEBPACK_IMPORTED_MODULE_43__/* .FetchInvoiceById.reducer */ .Y.reducer
    },
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(_Products_GetProductsApi__WEBPACK_IMPORTED_MODULE_2__/* .FetchProductApi.middleware */ .I.middleware).concat(_Products_FetchDayUseApi__WEBPACK_IMPORTED_MODULE_27__/* .FetchDayUseApi.middleware */ .d.middleware).concat(_Register_RegisterApi__WEBPACK_IMPORTED_MODULE_3__/* .RegisterApi.middleware */ .p.middleware).concat(_Register_LoginApi__WEBPACK_IMPORTED_MODULE_4__/* .LoginApi.middleware */ .I.middleware).concat(_Products_FetchImagesApi__WEBPACK_IMPORTED_MODULE_5__/* .FetchImagesApi.middleware */ .b.middleware).concat(_Products_FetchDetailsApi__WEBPACK_IMPORTED_MODULE_6__/* .FetchDetailsApi.middleware */ .k.middleware).concat(_Products_FetchReviewApi__WEBPACK_IMPORTED_MODULE_7__/* .FetchReviewApi.middleware */ .i.middleware).concat(_Products_FetchSupplementApi__WEBPACK_IMPORTED_MODULE_8__/* .FetchSupplementApi.middleware */ .a.middleware).concat(_Products_FetchTourIncludingApi__WEBPACK_IMPORTED_MODULE_9__/* .FetchTourIncludingApi.middleware */ .V.middleware).concat(_Products_FetchPolicyApi__WEBPACK_IMPORTED_MODULE_10__/* .FetchPolicyApi.middleware */ .B.middleware).concat(_Register_VerifyEmailApi__WEBPACK_IMPORTED_MODULE_11__/* .VerifyEmailApi.middleware */ .p.middleware).concat(_Products_AddReviewApi__WEBPACK_IMPORTED_MODULE_12__/* .AddReviewApi.middleware */ .t.middleware).concat(_Products_FetchProgramGroupsApi__WEBPACK_IMPORTED_MODULE_14__/* .FetchProgramGroupsApi.middleware */ .C.middleware).concat(_Products_FetchGroupPriceApi__WEBPACK_IMPORTED_MODULE_15__/* .FetchGroupPriceApi.middleware */ .V.middleware).concat(_Products_FetchExtraApi__WEBPACK_IMPORTED_MODULE_16__/* .FetchExtraApi.middleware */ .e.middleware).concat(_Reservation_AddReservationApi__WEBPACK_IMPORTED_MODULE_17__/* .AddReservationApi.middleware */ .$.middleware).concat(_Reservation_AddExtraApi__WEBPACK_IMPORTED_MODULE_18__/* .AddExtraApi.middleware */ .K.middleware).concat(_Reservation_AddReservationDetailsApi__WEBPACK_IMPORTED_MODULE_19__/* .AddReservationDetailsApi.middleware */ .E.middleware).concat(_Reservation_FetchPaymentApi__WEBPACK_IMPORTED_MODULE_20__/* .FetchPaymentApi.middleware */ .h.middleware).concat(_ForgetPassword_FetchForgetPassDataApi__WEBPACK_IMPORTED_MODULE_21__/* .FetchForgetPassDataApi.middleware */ .T.middleware).concat(_ForgetPassword_ResetPasswordApi__WEBPACK_IMPORTED_MODULE_23__/* .ResetPasswordApi.middleware */ .P.middleware).concat(_ForgetPassword_VerifyPasswordApi__WEBPACK_IMPORTED_MODULE_22__/* .VerifyPasswordApi.middleware */ .I.middleware).concat(_Filter_FetchNationalityApi__WEBPACK_IMPORTED_MODULE_24__/* .FetchNationalityApi.middleware */ .r.middleware).concat(_Filter_FetchCountryEnApi__WEBPACK_IMPORTED_MODULE_34__/* .FetchCountryEnApi.middleware */ .w.middleware).concat(_FetchLanguageApi__WEBPACK_IMPORTED_MODULE_26__/* .FetchLanguageApi.middleware */ .t.middleware).concat(_Products_FetchPackagesArApi__WEBPACK_IMPORTED_MODULE_29__/* .FetchPackagesArApi.middleware */ .N.middleware).concat(_Products_FetchPackagesEnApi__WEBPACK_IMPORTED_MODULE_28__/* .FetchPackagesEnApi.middleware */ .M.middleware).concat(_Products_ProgramDetailsAR_FetchDetailsARApi__WEBPACK_IMPORTED_MODULE_30__/* .FetchDetailsARApi.middleware */ .U.middleware).concat(_Products_ProgramDetailsAR_FetchTourIncludingArApi__WEBPACK_IMPORTED_MODULE_31__/* .FetchTourIncludingArApi.middleware */ .s.middleware).concat(_Products_ProgramDetailsAR_FetchPolicyArApi__WEBPACK_IMPORTED_MODULE_32__/* .FetchPolicyArApi.middleware */ .z.middleware).concat(_Products_ProgramDetailsAR_FetchTourExcludingArApi__WEBPACK_IMPORTED_MODULE_33__/* .FetchTourExcludingArApi.middleware */ .N.middleware).concat(_Filter_FetchTourTypeApi__WEBPACK_IMPORTED_MODULE_36__/* .FetchTourTypeApi.middleware */ .V.middleware).concat(_Filter_FetchCountryArApi__WEBPACK_IMPORTED_MODULE_35__/* .FetchCountryArApi.middleware */ .M.middleware).concat(_Reservation_FetchPaidReservation__WEBPACK_IMPORTED_MODULE_37__/* .FetchPaidReservation.middleware */ .U.middleware).concat(_Products_FetchSupplementArApi__WEBPACK_IMPORTED_MODULE_38__/* .FetchSupplementArApi.middleware */ .V.middleware).concat(_Filter_FetchCityEnApi__WEBPACK_IMPORTED_MODULE_39__/* .FetchCityEnApi.middleware */ .o.middleware).concat(_Filter_FetchCityArApi__WEBPACK_IMPORTED_MODULE_40__/* .FetchCityArApi.middleware */ .o.middleware).concat(_Filter_FetchTourTypeArApi__WEBPACK_IMPORTED_MODULE_41__/* .FetchTourTypeArApi.middleware */ .R.middleware).concat(_Reservation_FetchUnPaidReservation__WEBPACK_IMPORTED_MODULE_42__/* .FetchUnPaidReservation.middleware */ .J.middleware).concat(_Reservation_FetchInvoiceById__WEBPACK_IMPORTED_MODULE_43__/* .FetchInvoiceById.middleware */ .Y.middleware)
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ button),
/* harmony export */   "n": () => (/* binding */ container)
/* harmony export */ });
const container = {
    MuiContainer: {
        styleOverrides: {
            root: ({ ownerState  })=>({
                    ...ownerState.maxWidth === "lg" && {
                        maxWidth: "1350px !important"
                    }
                })
        }
    }
};
const button = {
    MuiButton: {
        styleOverrides: {
            root: {
                boxShadow: "none !important"
            }
        }
    }
};


/***/ }),

/***/ 6054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const main = {
    lightGray: "#B7B7B7",
    darkGray: "#989898",
    lightBlack: "#333333",
    payment: "#B3B3B3",
    counter: "#F3F3F3",
    bg: "#fff"
};
const PRIMARY = {
    main: "#E07026"
};
const SECONDARY = {
    main: "#007489"
};
const GRAY = {
    main: "#C7C7C7",
    light: "#FAFAFA"
};
const BODY = {
    main: "#333333",
    light: "#fff"
};
const ERROR = {
    main: "#D51A1A"
};
const palette = {
    primary: {
        ...PRIMARY
    },
    secondary: {
        ...SECONDARY
    },
    body: {
        ...BODY
    },
    gray: {
        ...GRAY
    },
    error: {
        ...ERROR
    },
    main: {
        ...main
    },
    background: {
        default: main.bg
    },
    text: {
        primary: main.lightBlack
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (palette);


/***/ }),

/***/ 137:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ThemeProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3195);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var stylis__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4615);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3139);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8440);
/* harmony import */ var _palette__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6054);
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9566);
/* harmony import */ var hooks_useStore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7819);
/* harmony import */ var _store_languageSlice__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4366);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([stylis__WEBPACK_IMPORTED_MODULE_5__, _emotion_react__WEBPACK_IMPORTED_MODULE_6__, _emotion_cache__WEBPACK_IMPORTED_MODULE_7__, _store_languageSlice__WEBPACK_IMPORTED_MODULE_11__]);
([stylis__WEBPACK_IMPORTED_MODULE_5__, _emotion_react__WEBPACK_IMPORTED_MODULE_6__, _emotion_cache__WEBPACK_IMPORTED_MODULE_7__, _store_languageSlice__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//









function ThemeProvider({ children  }) {
    const dir = (0,hooks_useStore__WEBPACK_IMPORTED_MODULE_10__/* .useAppSelector */ .C)(_store_languageSlice__WEBPACK_IMPORTED_MODULE_11__/* .getDir */ .XP);
    const FONT_En = "Montserrat , sans-serif";
    const FONT_Ar = "Cairo , sans-serif";
    let theme = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.createTheme)({
            direction: dir,
            typography: {
                fontFamily: dir === "ltr" ? FONT_En : FONT_Ar,
                ..._typography__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z
            },
            palette: _palette__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
            // shadows:shadows,
            components: {
                ..._components__WEBPACK_IMPORTED_MODULE_12__/* .container */ .n,
                ..._components__WEBPACK_IMPORTED_MODULE_12__/* .button */ .L
            },
            shape: {
                borderRadius: 4
            }
        });
    }, [
        dir
    ]);
    const cacheRtl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (dir === "rtl") {
            return (0,_emotion_cache__WEBPACK_IMPORTED_MODULE_7__["default"])({
                key: "muirtl",
                stylisPlugins: [
                    stylis__WEBPACK_IMPORTED_MODULE_5__.prefixer,
                    (stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_4___default())
                ]
            });
        } else {
            return (0,_emotion_cache__WEBPACK_IMPORTED_MODULE_7__["default"])({
                key: "css"
            });
        }
    }, [
        dir
    ]);
    theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.responsiveFontSizes)(theme);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react__WEBPACK_IMPORTED_MODULE_6__.CacheProvider, {
        value: cacheRtl,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.ThemeProvider, {
            theme: theme,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CssBaseline, {}),
                children
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function pxToRem(value) {
    return `${value / 16}rem`;
}
const typography = {
    fontWeightRegular: 400,
    fontWeightMedium: 600,
    fontWeightBold: 700,
    // fontSize: 18,
    h1: {
        fontWeight: 700,
        lineHeight: 80 / 64,
        fontSize: pxToRem(48)
    },
    h2: {
        fontWeight: 600,
        lineHeight: 64 / 48,
        fontSize: pxToRem(30)
    },
    h3: {
        fontWeight: 600,
        lineHeight: 1.5,
        fontSize: pxToRem(24)
    },
    h4: {
        fontWeight: 600,
        lineHeight: 1.5,
        fontSize: pxToRem(20)
    },
    h5: {
        fontWeight: 600,
        lineHeight: 1.5,
        fontSize: pxToRem(18)
    },
    h6: {
        fontWeight: 700,
        lineHeight: 28 / 18,
        fontSize: pxToRem(16)
    },
    subtitle1: {
        lineHeight: 1.5,
        fontSize: pxToRem(16),
        fontWeight: 600
    },
    subtitle2: {
        lineHeight: 22 / 14,
        fontSize: pxToRem(14),
        fontWeight: 600
    },
    body1: {
        fontSize: pxToRem(16)
    },
    body2: {
        fontSize: pxToRem(14)
    },
    caption: {
        lineHeight: 1.5,
        fontSize: pxToRem(12)
    },
    overline: {
        fontWeight: 700,
        lineHeight: 1.5,
        fontSize: pxToRem(12),
        letterSpacing: 1.1,
        textTransform: "uppercase"
    },
    button: {
        fontWeight: 600,
        lineHeight: 24 / 14,
        letterSpacing: 1.25,
        fontSize: pxToRem(14),
        textTransform: "capitalize",
        textDecoration: "none"
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (typography);


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 2081:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Call");

/***/ }),

/***/ 5631:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3819:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ 4475:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Container");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 5612:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 7934:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 5246:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Link");

/***/ }),

/***/ 8742:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 6042:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 1528:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Zoom");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 4156:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/useScrollTrigger");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4335:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit/query/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8890:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9709:
/***/ ((module) => {

"use strict";
module.exports = require("react-i18next");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3195:
/***/ ((module) => {

"use strict";
module.exports = require("stylis-plugin-rtl");

/***/ }),

/***/ 8440:
/***/ ((module) => {

"use strict";
module.exports = import("@emotion/cache");;

/***/ }),

/***/ 3139:
/***/ ((module) => {

"use strict";
module.exports = import("@emotion/react");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 4615:
/***/ ((module) => {

"use strict";
module.exports = import("stylis");;

/***/ }),

/***/ 9863:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"Sign in":"تسجيل الدخول","العربية":"English","Offers":"العروض","My Reservations":"الحجوزات","Contact Us":"تواصل معنا","Complaint and Suggestion":"الشكاوي والمقترحات","We are ready to travel":"نحن مستعدون للسفر","We are ready to serve you":"نحن مستعدون لخدمتكم","Outings":"العطل","Packages":"الباكدج","Day Use":"داي يوز","Hotels":"الفنادق","Transportation":"مواصلات","Flights":"رحلات جوية","Package":"الباقات","Tickets":"التذاكر","Restaurant":"مطعم","Country":"الدولة","Trip Date from":"تاريخ بداية الرجلة","Trip Date to":"تاريخ نهاية الرجلة","Search Results":"نتائج البحث","Tailored Services":"خدمات مخصصة","Search":"بحث","My Shopping list":"سلة المشتريات","My Reservation list":"قائمة الحجوزات","My WishList":"سلة المفضلة","Total Price":"السعر الكلي","Entertainment Trip, Historic Trip, Youth Journey":"رحلة ترفيهية، رحلة تاريخية، رحلة الشباب","More Details":"تفاصيل اكثر","Price":"السعر","Go to Home":"الرجوع للرئيسية","Your wishlist is empty":"سلة المفضلة فارغة","trip removed from wish list":"تم حذف الرحلة من المفضلة","removed successfully":"تم حذف الرحلة بنجاح","trip added to wish list":"تم اضافة الرحلة الي المفضلة","Partners":"الشركاء","See all":"مشاهدة الكل","City":"المدينة","Nationality":"الجنسية","Trip type":"نوع الرحلة","Pick a date":"اختر التاريخ","OTP is required":"OTP مطلوب","Verification failed!":"فشل التحقق. يرجى التحقق من OTP.","Email verified successfully!":"تم التحقق من البريد الإلكتروني بنجاح!","Verify Your Email":"تحقق من بريدك الإلكتروني","Verify Email":"تحقق من البريد الإلكتروني","Verifying...":"جارٍ التحقق...","Enter OTP":"أدخل OTP","Verification failed. Please check the OTP.":" فشل التحقق. يرجى التحقق من OTP.","Add to Wishlist":"اضافة الي المفضلة","Add to my shopping cart":"اضافة الي سلة المشتريات","Watch Video":"مشاهدة فيديو","Map":"الخريطة","Passenger data":"بيانات الحجز","Payment and confirm":"الدفع والتأكيد","Success":"نجاح","Pay":"دفع","Cancel":"الغاء","Print":"طباعة","Edit":"تعديل","Program Year":"السنة","Payment Status":"حالة الدفع","Reservation No":"رقم الحجز","Trip Date":"التاريخ","program year":"السنة","Customer Ref":"مرجع العميل","Paid":"مدفوع","All Unpaid Reservations":"سجل الحجوزات","All Paid Reservations":"كل المدفوعات","Unpaid":"غير مدفوع","Customer Name":"اسم العميل","Program Name":"اسم الرحلة","Reservation Ref":"مرجع الحجز","reservation sp":"رقم الفاتورة ","Number of Adult":"عدد الافراد","CHILD FROM 6 TO 12":"الأطفال (6-12 سنوات)","ADULT":"الافراد","Number of Children (1-6)":"عدد الأطفال (1-6 سنوات)","Number of Children (6-12)":"عدد الأطفال (6-12 سنوات)","Total Without Additional Services":"الإجمالي بدون خدمات إضافية","Additional Service Total":"إجمالي الخدمات الإضافية","Total":"الإجمالي","Price : ":"السعر : ","VAT":"ضريبة القيمة المضافة","Total with VAT":"الإجمالي مع ضريبة القيمة المضافة","EGP":"جنية مصري","Payment Error":"خطأ في الدفع","Please select at least one adult or child.":"يرجى اختيار شخص بالغ واحد على الأقل أو طفل.","paying...":" ...دفع","The total includes VAT":"السعر الكلي بالضريبة","Read Terms and conditions":"اقرأ الشروط والأحكام","I Accept Terms And Conditions and Cancellation policy":"أوافق على الشروط والأحكام وسياسة الإلغاء","No services available":"لا يوجد خدمات متاحة","No additional services available":"لا يوجد خدمات اضافية متاحة","Error loading extra services.":"خطأ في تحميل الخدمات","Error fetching data":"خطأ في تحميل الحجوزات","Additional Services":"الخدمات الاضافية","Available pax":"العدد المتاح","Start Price":"السعر","Duration time":"مدة الرحلة","Location":"المكان","Countries":"الدول","Please select a date":"من فضلك اختر تاريخ","Please select a city":"من فضلك اختر مدينة","Product Details":"تفاصيل المنتج","Error Loading Trips":"حدث خطأ أثناء تحميل الرحلات","Failed to load packages":"حدث خطأ أثناء تحميل الباقات","Failed to load Day Use":"حدث خطأ أثناء تحميل  الاستخدام اليومي","No Trips Details Found":"لم يتم العثور على تفاصيل للرحلات","No trips found":"لم يتم العثور على رحلات","No booking Details Found":"لم يتم العثور على تفاصيل الحجز","Tour Including":"ما يشمل الرحلة","Cancellation policy":"سياسة الإلغاء","days":"أيام","Price Not Available":"السعر غير متوفر","Overview":"نظرة عامة","Supplement":"الإضافات","Photo Gallery":"معرض الصور","Reviews":"التقييمات","No overview available":"لا توجد نظرة عامة متوفرة","Additional Info":"معلومات إضافية","Start Date":"تاريخ البدء","End Date":"تاريخ الانتهاء","The price includes supplement :":"السعر يشمل الإضافات : ","No supplements available":"لا توجد إضافات متوفرة","All prices don\'t include VAT":"جميع الأسعار لا تشمل ضريبة القيمة المضافة","No images available":"لا توجد صور متوفرة","Failed to load reviews. Please try again.":"فشل في تحميل التقييمات. حاول مرة أخرى.","No reviews available":"لا توجد تقييمات متوفرة","Rate this program":"قيم هذه الرحلة","Review submitted مشاركة عبر!":"تم ارسال التقييم بنجاح","Submit":"ارسال","Error Downloading Data":"خطأ في تحميل البيانات","Error loading details.":"خطأ في تحميل البيانات","All Trips":"كل الرحلات","Error loading data":"خطأ في تحميل البيانات","No Tour Including available.":"لا يوجد","No Tour policy available.":"لا يوجد","Book Now":"حجز الان","Book":"حجز","Confirm":"تأكيد","Payment Successful":"تم الدفع بنجاح","Response Code":"رمز الاستجابة","Order ID":"رقم الطلب","Payment Failed":"فشل الدفع","Payment Cancelled":"تم إلغاء الدفع","Missing Information":"معلومات مفقودة","Please make sure all payment details are filled out correctly.":"يرجى التأكد من تعبئة جميع تفاصيل الدفع بشكل صحيح.","Payment data is missing or failed!":"بيانات الدفع مفقودة أو فشلت!","Back":"الرجوع","Failed to submit review. Please try again.":"فشل من فضلك حاول مرة اخري","Failed to fetch payment data":"فشل في عملية الدفع من فضلك حاول مرة اخري","You have already submitted a review for this trip.":"لقد كتبت بالفعل تعليق لهذه الرحلة","already entered a comment":"لقد كتبت بالفعل تعليق لهذه الرحلة","Share via":"مشاركة عبر","Please write a comment and select a rating.":"من فضلك اكتب تعليق واختر التقييم ","User not logged in or missing information":"المستخدم غير مسجل او هناك معلومات ناقصة","You must be logged in to submit a review.":"يجب التسجيل اولا","Write your feedback here..":"اكتب تقييمك هنا","Unable to load review form":"تعذر تحميل نموذج التقييم","Planning a vacation?":"تخطط لقضاء عطلة؟","Choose your holiday packages. Book online or talk to our holiday experts":"اختر باقات عطلتك. احجز عبر الإنترنت أو تحدث إلى خبراء العطلات لدينا","Royal Promenade":"الممشى الملكي","Did you wish to spend a day as if you were a king? Only on our royal promenade, you can do so by sailing across the Nile to reach King Farouk\'s Rest house.":"هل تمنيت قضاء يوم كأنك ملك؟ فقط على ممشانا الملكي يمكنك ذلك من خلال الإبحار عبر النيل للوصول إلى استراحة الملك فاروق.","Home":"الصفحة الرئيسية","About Us":"من نحن","Cities":"المدن","Information":"معلومات","FAQs":"الأسئلة الشائعة","Vision":"الرؤية","Goals":"الأهداف","Welcome":"مرحبا","Logout":"تسجيل الخروج","Related links":"روابط ذات صلة","Ministry of Tourism":"وزارة السياحة","Ministry of Antiquities":"وزارة الآثار","Ministry of Environment":"وزارة البيئة","Ministry of Education":"وزارة التعليم","Egyptian Government Portal":"بوابة الحكومة المصرية","Subscribe to our newsletter":"اشترك في نشرتنا الإخبارية","Send":"إرسال","Social media":"وسائل التواصل الاجتماعي","Touf w Shof. 2024 - All Rights Reserved":"طوف وشوف. 2024 - جميع الحقوق محفوظة","Created by ITD":"تم الإنشاء بواسطة ITD","Leave a message":"اترك رسالة","Enter your name":"أدخل اسمك","Enter your Email":"أدخل بريدك الإلكتروني","Enter your Message":"أدخل رسالتك","Enter your Name":"أدخل الاسم","Enter your Phone":"أدخل رقم الهاتف","Have Questions? Contact Us":"هل لديك أسئلة؟ تواصل معنا","Your Email":"الايميل","Your Name":"الاسم","Your Phone":"الهاتف","Your Message":"رسالتك"}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6377,6964,5675,2952,1664,7901,4740,5681,6766,2481,7212,4793,8346,3603,4963], () => (__webpack_exec__(5656)));
module.exports = __webpack_exports__;

})();