"use strict";
exports.id = 1911;
exports.ids = [1911];
exports.modules = {

/***/ 8173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ ClientStorage)
/* harmony export */ });
const ClientStorage = {
    get (key) {
        if (false) {}
        return null;
    },
    set (key, value) {
        if (false) {}
    }
};


/***/ }),

/***/ 1911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _components_DetailsTabs)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/icons-material/TaskAlt"
var TaskAlt_ = __webpack_require__(9960);
var TaskAlt_default = /*#__PURE__*/__webpack_require__.n(TaskAlt_);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/Tabs"
var Tabs_ = __webpack_require__(8544);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs_);
// EXTERNAL MODULE: external "@mui/material/Tab"
var Tab_ = __webpack_require__(1307);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab_);
// EXTERNAL MODULE: external "@mui/material/Stack"
var Stack_ = __webpack_require__(8742);
var Stack_default = /*#__PURE__*/__webpack_require__.n(Stack_);
// EXTERNAL MODULE: external "@mui/material/Divider"
var Divider_ = __webpack_require__(3646);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_);
// EXTERNAL MODULE: external "@mui/material/ImageList"
var ImageList_ = __webpack_require__(4287);
var ImageList_default = /*#__PURE__*/__webpack_require__.n(ImageList_);
// EXTERNAL MODULE: external "@mui/material/ImageListItem"
var ImageListItem_ = __webpack_require__(4298);
var ImageListItem_default = /*#__PURE__*/__webpack_require__.n(ImageListItem_);
// EXTERNAL MODULE: external "@mui/material/Avatar"
var Avatar_ = __webpack_require__(2120);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./store/Products/FetchImagesApi.ts
var FetchImagesApi = __webpack_require__(3361);
// EXTERNAL MODULE: ./pages/productDetails/_components/BookButton.tsx
var BookButton = __webpack_require__(5556);
// EXTERNAL MODULE: ./store/Products/FetchReviewApi.ts
var FetchReviewApi = __webpack_require__(9225);
// EXTERNAL MODULE: ./store/Products/FetchSupplementApi.ts
var FetchSupplementApi = __webpack_require__(8288);
// EXTERNAL MODULE: external "@mui/icons-material/StarOutlineRounded"
var StarOutlineRounded_ = __webpack_require__(5784);
var StarOutlineRounded_default = /*#__PURE__*/__webpack_require__.n(StarOutlineRounded_);
// EXTERNAL MODULE: external "@mui/icons-material/StarRounded"
var StarRounded_ = __webpack_require__(5297);
var StarRounded_default = /*#__PURE__*/__webpack_require__.n(StarRounded_);
// EXTERNAL MODULE: external "@mui/material/Rating"
var Rating_ = __webpack_require__(802);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating_);
;// CONCATENATED MODULE: ./components/products/UserRating.tsx





const UserRating = (props)=>{
    const [valueRating, setValueRating] = external_react_default().useState(2);
    const ratingValue = typeof props.rating === "string" ? parseFloat(props.rating) : props.rating;
    const { readOnly  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
        name: "half-rating-read",
        defaultValue: 2,
        precision: 0.5,
        value: ratingValue,
        onChange: (event, newValue)=>{
            setValueRating(newValue);
        },
        readOnly: readOnly ? true : false,
        sx: {
            "& .MuiRating-iconFilled": {
                color: "primary.main"
            },
            "& .MuiRating-iconEmpty": {
                color: "primary.main"
            },
            zIndex: "12"
        },
        icon: /*#__PURE__*/ jsx_runtime_.jsx((StarRounded_default()), {
            fontSize: "inherit"
        }),
        emptyIcon: /*#__PURE__*/ jsx_runtime_.jsx((StarOutlineRounded_default()), {
            fontSize: "inherit"
        })
    });
};
/* harmony default export */ const products_UserRating = (UserRating);

// EXTERNAL MODULE: ./pages/productDetails/ReviewForm.tsx
var ReviewForm = __webpack_require__(871);
// EXTERNAL MODULE: ./components/Loading/Loading.tsx
var Loading = __webpack_require__(905);
// EXTERNAL MODULE: ./store/Products/ProgramDetailsAR/FetchTourExcludingArApi.ts
var FetchTourExcludingArApi = __webpack_require__(384);
// EXTERNAL MODULE: ./hooks/useLocalStroge.ts
var useLocalStroge = __webpack_require__(8173);
// EXTERNAL MODULE: ./store/Products/FetchSupplementArApi.ts
var FetchSupplementArApi = __webpack_require__(3884);
// EXTERNAL MODULE: external "@mui/material/Modal"
var Modal_ = __webpack_require__(9564);
var Modal_default = /*#__PURE__*/__webpack_require__.n(Modal_);
;// CONCATENATED MODULE: ./pages/productDetails/_components/DetailsTabs.tsx
/* eslint-disable @next/next/no-img-element */ /* eslint-disable react-hooks/exhaustive-deps */ 
























const DetailsTabs = ({ id , productData  })=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const { 0: selectedImage , 1: setSelectedImage  } = (0,external_react_.useState)("");
    const handleOpen = (image)=>{
        setSelectedImage(image);
        setOpen(true);
    };
    const handleClose = ()=>{
        setOpen(false);
        setSelectedImage("");
    };
    const { t  } = (0,external_react_i18next_.useTranslation)();
    const router = (0,router_.useRouter)();
    const [value, setValue] = external_react_default().useState(0);
    const language = useLocalStroge/* ClientStorage.get */.j.get("language") || "en";
    const code = router.query.code ? parseInt(router.query.code, 10) : undefined;
    const languagecode = router.query.languagecode ? parseInt(router.query.languagecode, 10) : undefined;
    const programyear = router.query.programyear ? parseInt(router.query.programyear, 10) : undefined;
    // Fetch images
    const { data , error: imgError , isLoading: isLoadingImages ,  } = (0,FetchImagesApi/* useGetImgQuery */.c)({
        code,
        programyear
    });
    const tripImages = data?.items || [];
    // Fetch reviews
    const { data: reviewData , error: reviewError , isLoading: reviewLoading , refetch ,  } = (0,FetchReviewApi/* useGetReviewQuery */.y)({
        code,
        programyear
    });
    const reviews = reviewData?.items || [];
    // Fetch Supplement
    const { data: SupplementData , error: supplementError , isLoading: supplementLoading ,  } = (0,FetchSupplementApi/* useGetSupplementQuery */.h)({
        code,
        programyear
    }, {
        skip: language !== "en"
    });
    const { data: SupplementArData , error: supplementArError , isLoading: supplementArLoading ,  } = (0,FetchSupplementArApi/* useGetSupplementArQuery */.W)({
        code,
        programyear
    }, {
        skip: language !== "ar"
    });
    const Supplements = language === "ar" ? SupplementArData?.items || [] : SupplementData?.items || [];
    // Fetch TourExcludingAr
    const queryParamsInlude = {
        code,
        programyear
    };
    const { data: TourExcludingAr , error: TourExcludingArError  } = (0,FetchTourExcludingArApi/* useGetTourExcludingArQuery */.a)(queryParamsInlude, {
        skip: language !== "ar"
    });
    const TourExcluding = TourExcludingAr?.items[0];
    // Error and loading handling
    if (imgError || reviewError || supplementError || supplementArError) {
        return /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
            children: t("Error loading data")
        });
    }
    const handleChange = (event, newValue)=>{
        setValue(newValue);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
        sx: {
            mb: 5
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Tabs_default()), {
                value: value,
                onChange: handleChange,
                "aria-label": "Product Details Tabs",
                variant: "scrollable",
                scrollButtons: "auto",
                allowScrollButtonsMobile: true,
                sx: {
                    "& .MuiTabs-flexContainer": {
                        justifyContent: "space-between",
                        overflowX: "auto",
                        scrollbarWidth: "thin"
                    },
                    px: 2,
                    mb: 1,
                    "@media (max-width: 600px)": {
                        "& .MuiTabs-flexContainer": {
                            justifyContent: "unset"
                        }
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        label: t("Overview")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        label: t("Supplement")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        label: t("Photo Gallery")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        label: t("Reviews")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(TabPanel, {
                value: value,
                index: 0,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "body2",
                        children: t(productData?.OverView || "No overview available")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "subtitle2",
                        sx: {
                            my: 2
                        },
                        children: t("Additional Info")
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                        variant: "body2",
                        children: [
                            t("Start Date"),
                            ": ",
                            t(productData?.startDate || "No start date available")
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                        variant: "body2",
                        children: [
                            t("End Date"),
                            ": ",
                            t(productData?.endDate || "No end date available")
                        ]
                    }),
                    TourExcluding?.TOUREXCLUDING && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "body2",
                        children: t(TourExcluding.TOUREXCLUDING)
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BookButton["default"], {
                        code: code,
                        programyear: programyear,
                        languagecode: languagecode
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(TabPanel, {
                value: value,
                index: 1,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "subtitle2",
                        sx: {
                            my: 2
                        },
                        children: t("The price includes supplement :")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Stack_default()), {
                        direction: "column",
                        spacing: 2,
                        children: supplementLoading && supplementArLoading ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {}) : Supplements.length > 0 ? Supplements.map((supplement, index)=>/*#__PURE__*/ jsx_runtime_.jsx(SupplementItem, {
                                description: supplement["the_price_includes_supplement"]
                            }, index)) : /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "body2",
                            children: t("No supplements available")
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                        sx: {
                            mt: 8,
                            mb: 2
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                        direction: "row",
                        spacing: 2,
                        alignItems: "center",
                        sx: {
                            color: "primary.main"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((TaskAlt_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "subtitle1",
                                children: t("All prices don't include VAT")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                value: value,
                index: 2,
                children: isLoadingImages ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {}) : tripImages.length > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ImageList_default()), {
                            cols: 4,
                            rowHeight: 140,
                            children: tripImages.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((ImageListItem_default()), {
                                    sx: {
                                        mx: 2,
                                        cursor: "pointer"
                                    },
                                    onClick: ()=>handleOpen(item.image.startsWith("https") ? item.image : `https://${item.image}`),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: item.image.startsWith("https") ? item.image : `https://${item.image}`,
                                        alt: item.img_name,
                                        style: {
                                            width: "150px",
                                            height: "100px",
                                            objectFit: "cover"
                                        }
                                    })
                                }, index))
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Modal_default()), {
                            open: open,
                            onClose: handleClose,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    position: "absolute",
                                    top: "50%",
                                    left: "50%",
                                    transform: "translate(-50%, -50%)",
                                    bgcolor: "#ffffffe0",
                                    boxShadow: 24,
                                    p: 2,
                                    width: "500px",
                                    height: "400px",
                                    outline: "none",
                                    borderRadius: "8px",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    "@media (max-width: 600px)": {
                                        width: "90%",
                                        height: "auto"
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: selectedImage,
                                    alt: "Selected",
                                    style: {
                                        maxWidth: "100%",
                                        maxHeight: "100%",
                                        objectFit: "contain",
                                        borderRadius: "8px"
                                    }
                                })
                            })
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "body2",
                    children: t("No images available")
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TabPanel, {
                value: value,
                index: 3,
                children: reviewLoading ? /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "body2",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {})
                }) : reviewError ? /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "body2",
                    color: "error",
                    children: "Failed to load reviews. Please try again."
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ReviewSection, {
                            reviews: reviews
                        }),
                        code && programyear ? /*#__PURE__*/ jsx_runtime_.jsx(ReviewForm["default"], {
                            code: code,
                            programyear: programyear,
                            onReviewAdded: ()=>refetch()
                        }) : /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "body2",
                            children: "Unable to load review form"
                        })
                    ]
                })
            })
        ]
    });
};
// Supplement Item component
const SupplementItem = ({ description  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
        direction: "row",
        spacing: 2,
        alignItems: "center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((TaskAlt_default()), {
                sx: {
                    color: "secondary.main"
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                variant: "body2",
                children: description
            })
        ]
    });
// Review Section component
const ReviewSection = ({ reviews  })=>{
    const { t  } = (0,external_react_i18next_.useTranslation)();
    return /*#__PURE__*/ jsx_runtime_.jsx((Stack_default()), {
        spacing: 2,
        children: reviews.length > 0 ? reviews.map((review, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((Stack_default()), {
                direction: "row",
                alignItems: "top",
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        variant: "square",
                        sx: {
                            width: 56,
                            height: 56
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "subtitle2",
                                children: review.customer
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "body2",
                                children: review.review
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                sx: {
                                    my: 2
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(products_UserRating, {
                        readOnly: true,
                        rating: review.rate
                    })
                ]
            }, index)) : /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
            variant: "body2",
            children: t("No reviews available")
        })
    });
};
function TabPanel(props) {
    const { children , value , index , ...other } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        role: "tabpanel",
        hidden: value !== index,
        id: `simple-tabpanel-${index}`,
        "aria-labelledby": `simple-tab-${index}`,
        ...other,
        children: value === index && /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
            sx: {
                p: 3
            },
            children: children
        })
    });
}
/* harmony default export */ const _components_DetailsTabs = (DetailsTabs);


/***/ })

};
;