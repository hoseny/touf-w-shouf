"use strict";
exports.id = 871;
exports.ids = [871];
exports.modules = {

/***/ 871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_Products_AddReviewApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1670);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_FacebookOutlined__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(582);
/* harmony import */ var _mui_icons_material_FacebookOutlined__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FacebookOutlined__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5631);
/* harmony import */ var _mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(802);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Loading_Loading__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(905);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_14__);















const ReviewForm = ({ code , programyear , onReviewAdded  })=>{
    const { 0: review , 1: setReview  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: rate , 1: setRate  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: errorMessage , 1: setErrorMessage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [addReview, { isLoading , isSuccess , isError  }] = (0,_store_Products_AddReviewApi__WEBPACK_IMPORTED_MODULE_2__/* .useAddReviewMutation */ .M)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
    const handleSubmit = async ()=>{
        const custCode = localStorage.getItem("custcode");
        const name = localStorage.getItem("NAME");
        const token = localStorage.getItem("token");
        if (!token) {
            setErrorMessage(t("You must be logged in to submit a review."));
            setTimeout(()=>{
                router.push("/login");
            }, 2000);
            return;
        }
        if (!custCode || !name) {
            console.error(t("User not logged in or missing information"));
            return;
        }
        if (review.trim() === "" || rate === 0) {
            setErrorMessage(t("Please write a comment and select a rating."));
            return;
        }
        try {
            const custId = Number(custCode);
            if (isNaN(custId)) {
                console.error("Invalid custCode");
                return;
            }
            const response = await addReview({
                code,
                programyear,
                cust: custId,
                rate,
                review
            }).unwrap();
            if (response.Review && response.Review.includes(t("already entered a comment"))) {
                setErrorMessage(t("You have already submitted a review for this trip."));
            } else {
                setReview("");
                setRate(0);
                setErrorMessage(null);
                onReviewAdded();
            }
        } catch (error) {
            console.error("Failed to submit review:", error);
            if (error.status === 400 && error.data?.Review) {
                setErrorMessage(error.data.Review.trim());
            } else {
                setErrorMessage(t("Failed to submit review. Please try again."));
            }
        }
    };
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_14__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
        sx: {
            my: 3
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_4___default()), {
                id: "outlined-basic",
                placeholder: t("Write your feedback here.."),
                variant: "outlined",
                fullWidth: true,
                multiline: true,
                maxRows: 5,
                minRows: 4,
                value: review,
                onChange: (e)=>setReview(e.target.value)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    my: 2
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                        variant: "h6",
                        children: t("Rate this program")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_11___default()), {
                        name: "rating",
                        value: rate,
                        onChange: (event, newValue)=>setRate(newValue || 0)
                    })
                ]
            }),
            isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading_Loading__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
            isSuccess && !errorMessage && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                variant: "body2",
                color: "success.main",
                children: t("Review submitted successfully!")
            }),
            isError || errorMessage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                variant: "body2",
                color: "error.main",
                children: errorMessage
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
                direction: "row",
                justifyContent: "space-between",
                alignItems: "center",
                sx: {
                    mt: 2,
                    color: "body.main"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_5___default()), {
                    variant: "contained",
                    size: "large",
                    onClick: handleSubmit,
                    children: t("Submit")
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
                direction: "row",
                alignItems: "center",
                spacing: 2,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                        variant: "body1",
                        children: t("Share via")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default()), {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FacebookOutlined__WEBPACK_IMPORTED_MODULE_9___default()), {
                            sx: {
                                color: "body.main"
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default()), {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_10___default()), {
                            sx: {
                                color: "body.main"
                            }
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReviewForm);


/***/ }),

/***/ 1670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ useAddReviewMutation),
/* harmony export */   "t": () => (/* binding */ AddReviewApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const AddReviewApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "AddReview",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            addReview: builder.mutation({
                query: ({ code , programyear , cust , rate , review  })=>({
                        url: `programReview/${code}/${programyear}`,
                        method: "POST",
                        body: {
                            cust,
                            rate,
                            review
                        }
                    })
            })
        })
});
const { useAddReviewMutation  } = AddReviewApi;


/***/ })

};
;