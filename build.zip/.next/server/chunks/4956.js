"use strict";
exports.id = 4956;
exports.ids = [4956];
exports.modules = {

/***/ 4956:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1168);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_Reservation_FetchPaymentApi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9958);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Loading_Loading__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(905);











const Payment = ({ handleBack  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const { 0: ref , 1: setRef  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: sp , 1: setSp  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const customer_ref =  false ? 0 : null;
    const customerName =  false ? 0 : null;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, []);
    const { data  } = (0,_store_Reservation_FetchPaymentApi__WEBPACK_IMPORTED_MODULE_8__/* .useGetPaymentQuery */ .a)(ref && sp ? {
        ref,
        sp
    } : undefined, {
        skip: !ref || !sp
    });
    const paymentData = data?.items || [];
    const programname = paymentData[0]?.programname || t("Program name not available");
    const programyear = paymentData[0]?.programyear || t("Program year not available");
    const TripDate = paymentData[0]?.["TripDate :"] || t("Program date not available");
    const customerRef = paymentData[0]?.["Customerref :"] || customer_ref;
    const reservationRef = paymentData[0]?.["reservationRef "] || ref;
    const reservationsp = paymentData[0]?.["reservationsp "] || sp;
    const total = paymentData[0]?.["Total "] || 0;
    const vat = paymentData[0]?.["Vat "] || 0;
    const totalWithVat = paymentData[0]?.["TheTotalincludesVat "] || 0;
    const numberOfAdults = paymentData[0]?.["TheNumberOfADULTX"] || 0;
    const numberOfChildrenUnder6 = paymentData[0]?.["TheNumberOfCHILD FROM 1 TO 6X"] || 0;
    const numberOfChildrenBetween6And12 = paymentData[0]?.["TheNumberOfCHILD FROM 6 TO 12X"] || 0;
    const TheNumberOfCHILDFROM6TO12DayUseX = paymentData[0]?.["TheNumberOfCHILD FROM 6 TO 12 DayUseX"] || 0;
    const TheNumberOfADULTINSINGLEX = paymentData[0]?.["TheNumberOfADULT IN SINGLEX"] || 0;
    const TheNumberOfADULTINDOUBLEX = paymentData[0]?.["TheNumberOfADULT IN DOUBLEX"] || 0;
    const TheNumberOfADULTINTRIPLEX = paymentData[0]?.["TheNumberOfADULT IN TRIPLEX"] || 0;
    const TheNumberOfADULTINSUITEX = paymentData[0]?.["TheNumberOfADULT IN SUITEX"] || 0;
    const TheNumberOfADULTINQUARTERX = paymentData[0]?.["TheNumberOfADULT IN QUARTERX"] || 0;
    const totalWithoutAdditionalService = paymentData[0]?.["TheTotalwithoutadditionalservice"] || 0;
    const totalAdditionalService = paymentData[0]?.["TheTotaladditionalservice"] || 0;
    // fetch check out id
    const fetchPaymentData = async ()=>{
        try {
            setIsLoading(true);
            // const urlTrue = 'http://localhost:3000/Payment/Success';
            // const urlFalse = 'http://localhost:3000/Payment/Failed';
            // const urlTrue = 'https://touf-we-shouf.vercel.app/Payment/Success';
            // const urlFalse = 'https://touf-we-shouf.vercel.app/Payment/Failed';
            const urlTrue = "https://www.toufwshouf.travel/Payment/Success";
            const urlFalse = "https://www.toufwshouf.travel/Payment/Failed";
            const accessType = "Web";
            const custRef = customerRef;
            const invNo = reservationsp;
            const invAmount = total;
            const appSession =  false ? 0 : "123456";
            // const appSession = '123456';
            const url = `https://app.misrtravelco.net:4444/ords/invoice/public/GetCheckOut?urlFalse=${urlFalse}&urlTrue=${urlTrue}&accessType=${accessType}&custRef=${custRef}&invNo=${invNo}&invAmount=${invAmount}&appSession=${appSession}`;
            const response = await fetch(url);
            if (!response.ok) {
                setIsLoading(false);
                throw new Error("Failed to fetch payment data");
            }
            return await response.json();
        } catch (error) {
            setIsLoading(false);
            const errMessage = error.response?.data?.errMessage || "Unexpected error occurred";
            console.error(errMessage);
            sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire(errMessage);
        }
    };
    //add Geidea
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = "https://www.merchant.geidea.net/hpp/geideaCheckout.min.js";
        script.async = true;
        script.onload = ()=>console.log("GeideaCheckout script loaded successfully");
        script.onerror = ()=>console.error("Failed to load GeideaCheckout script");
        document.body.appendChild(script);
        return ()=>{
            document.body.removeChild(script);
        };
    }, []);
    // Handle payment success
    const onSuccess = (data)=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire({
            icon: "success",
            title: t("Payment Successful"),
            html: `
        <strong>${t("Response Code")}:</strong> ${data.responseCode}<br />
        <strong>${t("Order ID")}:</strong> ${data.orderId}
        `
        });
    };
    // Handle payment error
    const onError = (data)=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire({
            icon: "error",
            title: t("Payment Failed"),
            html: `
        <strong>${t("Response Code")}:</strong> ${data.responseCode}<br />
        <strong>${t("Order ID")}:</strong> ${data.orderId}
        `
        });
    };
    // Handle payment cancellation
    const onCancel = ()=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire({
            icon: "warning",
            title: t("Payment Cancelled")
        });
    };
    // Start payment
    const startPayment = async ()=>{
        setIsLoading(true);
        if (!reservationRef || !customerRef || !total) {
            sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire({
                icon: "error",
                title: t("Missing Information"),
                text: t("Please make sure all payment details are filled out correctly.")
            });
            return;
        }
        const paymentData = await fetchPaymentData();
        if (!paymentData || paymentData.errMessage !== "Success") {
            alert(t("Payment data is missing or failed!"));
            return;
        }
        const checkoutId = paymentData.checkout;
        console.log("checkoutId", checkoutId);
        if (window.GeideaCheckout) {
            const GeideaCheckout = window.GeideaCheckout;
            const payment = new GeideaCheckout(onSuccess, onError, onCancel);
            payment.startPayment(checkoutId);
        } else {
            setIsLoading(false);
            sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire({
                icon: "error",
                title: t("Script Not Loaded"),
                text: t("GeideaCheckout script is not loaded yet. Please try again later.")
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                container: true,
                spacing: 5,
                children: [
                    isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading_Loading__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                        md: 5,
                        xs: 12,
                        item: true,
                        sx: {
                            margin: "auto"
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_6___default()), {
                            elevation: 1,
                            sx: {
                                backgroundColor: "#FAFAFA",
                                p: 2,
                                mt: 5
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    variant: "h3",
                                    children: programname
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    sx: {
                                        mt: 3
                                    },
                                    direction: "column",
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Customer Name"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: customerName
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Trip Date"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TripDate
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("reservation sp"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: reservationsp
                                                })
                                            ]
                                        }),
                                        numberOfAdults > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Adult"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: numberOfAdults
                                                })
                                            ]
                                        }),
                                        TheNumberOfADULTINSINGLEX > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Adult Single"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TheNumberOfADULTINSINGLEX
                                                })
                                            ]
                                        }),
                                        TheNumberOfADULTINDOUBLEX > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Adult Double"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TheNumberOfADULTINDOUBLEX
                                                })
                                            ]
                                        }),
                                        TheNumberOfADULTINTRIPLEX > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Adult in Triple"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TheNumberOfADULTINTRIPLEX
                                                })
                                            ]
                                        }),
                                        TheNumberOfADULTINQUARTERX > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Adult in Quarter"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TheNumberOfADULTINQUARTERX
                                                })
                                            ]
                                        }),
                                        TheNumberOfADULTINSUITEX > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Adult in Suite"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TheNumberOfADULTINSUITEX
                                                })
                                            ]
                                        }),
                                        TheNumberOfCHILDFROM6TO12DayUseX > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number Of CHILD (6 TO 12) DayUse"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: TheNumberOfCHILDFROM6TO12DayUseX
                                                })
                                            ]
                                        }),
                                        numberOfChildrenUnder6 > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Children (1-6)"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: numberOfChildrenUnder6
                                                })
                                            ]
                                        }),
                                        numberOfChildrenBetween6And12 > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Number of Children (6-12)"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: numberOfChildrenBetween6And12
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Total Without Additional Services"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: totalWithoutAdditionalService
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Additional Service Total"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: totalAdditionalService
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Total"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: total
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("VAT"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: vat
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            direction: "row",
                                            justifyContent: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body2",
                                                    children: [
                                                        t("Total with VAT"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    variant: "body1",
                                                    children: totalWithVat
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                container: true,
                sx: {
                    my: 3
                },
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                        item: true,
                        xs: 3,
                        sx: {
                            margin: "auto"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                            onClick: startPayment,
                            variant: "contained",
                            fullWidth: true,
                            size: "large",
                            children: t("Confirm")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_3___default()), {
                        item: true,
                        xs: 3,
                        sx: {
                            margin: "auto"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                            variant: "outlined",
                            onClick: ()=>handleBack(),
                            fullWidth: true,
                            size: "large",
                            children: t("Back")
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Payment);


/***/ }),

/***/ 9958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useGetPaymentQuery),
/* harmony export */   "h": () => (/* binding */ FetchPaymentApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPaymentApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PaymentData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getPayment: builder.query({
                query: ({ ref , sp  })=>`/payment/${ref}/${sp}`
            })
        })
});
const { useGetPaymentQuery  } = FetchPaymentApi;


/***/ })

};
;