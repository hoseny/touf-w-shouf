"use strict";
exports.id = 4793;
exports.ids = [4793];
exports.modules = {

/***/ 612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetDetailsQuery),
/* harmony export */   "k": () => (/* binding */ FetchDetailsApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchDetailsApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "DetailsData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getDetails: builder.query({
                query: ({ code , programyear , languagecode  })=>`/detailsesProgram/${code}/${programyear}/${languagecode}`
            })
        })
});
const { useGetDetailsQuery  } = FetchDetailsApi;


/***/ }),

/***/ 3902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ FetchDetailsARApi),
/* harmony export */   "b": () => (/* binding */ useGetDetailsArQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchDetailsARApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "DetailsArData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getDetailsAr: builder.query({
                query: ({ code , programyear , languagecode  })=>`/programDtlsAR/${code}/${programyear}/${languagecode}`
            })
        })
});
const { useGetDetailsArQuery  } = FetchDetailsARApi;


/***/ })

};
;