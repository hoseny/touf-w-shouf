"use strict";
exports.id = 7212;
exports.ids = [7212];
exports.modules = {

/***/ 4868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ useAddUserMutation),
/* harmony export */   "p": () => (/* binding */ RegisterApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const RegisterApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "AddUser",
    tagTypes: [
        "Users"
    ],
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            addUser: builder.mutation({
                query: (values)=>({
                        url: "/client/",
                        method: "POST",
                        body: values,
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }),
                invalidatesTags: [
                    "Users"
                ]
            })
        })
});
const { useAddUserMutation  } = RegisterApi;


/***/ }),

/***/ 8019:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ VerifyEmailApi),
/* harmony export */   "q": () => (/* binding */ useVerifyEmailMutation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const VerifyEmailApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "VerifyEmail",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            verifyEmail: builder.mutation({
                query: ({ OTP , p_Mail , TEL  })=>({
                        url: `validation/${OTP}`,
                        method: "POST",
                        body: {
                            p_Mail,
                            TEL
                        }
                    })
            })
        })
});
const { useVerifyEmailMutation  } = VerifyEmailApi;


/***/ })

};
;