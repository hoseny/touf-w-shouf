"use strict";
exports.id = 2382;
exports.ids = [2382];
exports.modules = {

/***/ 2382:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_StarOutlineRounded__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5784);
/* harmony import */ var _mui_icons_material_StarOutlineRounded__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_StarOutlineRounded__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_StarRounded__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5297);
/* harmony import */ var _mui_icons_material_StarRounded__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_StarRounded__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(802);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);





const ProductRating = (props)=>{
    const [valueRating, setValueRating] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(2);
    const ratingValue = typeof props.rating === "string" ? parseFloat(props.rating) : props.rating;
    const { readOnly  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_3___default()), {
        name: "half-rating-read",
        defaultValue: 2,
        precision: 0.5,
        value: ratingValue,
        onChange: (event, newValue)=>{
            setValueRating(newValue);
        },
        readOnly: readOnly ? true : false,
        sx: {
            "& .MuiRating-iconFilled": {
                color: "primary.main"
            },
            "& .MuiRating-iconEmpty": {
                color: "primary.main"
            },
            zIndex: "12"
        },
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_StarRounded__WEBPACK_IMPORTED_MODULE_2___default()), {
            fontSize: "inherit"
        }),
        emptyIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_StarOutlineRounded__WEBPACK_IMPORTED_MODULE_1___default()), {
            fontSize: "inherit"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductRating);


/***/ })

};
;