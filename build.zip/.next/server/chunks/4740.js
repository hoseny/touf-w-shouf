"use strict";
exports.id = 4740;
exports.ids = [4740];
exports.modules = {

/***/ 8173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ ClientStorage)
/* harmony export */ });
const ClientStorage = {
    get (key) {
        if (false) {}
        return null;
    },
    set (key, value) {
        if (false) {}
    }
};


/***/ }),

/***/ 8631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ useGetCityArQuery),
/* harmony export */   "o": () => (/* binding */ FetchCityArApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchCityArApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "CityArData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/ProgAR/"
    }),
    endpoints: (builder)=>({
            getCityAr: builder.query({
                query: ({ Country , Region  })=>`/getCityAR/${Country}/${Region}`
            })
        })
});
const { useGetCityArQuery  } = FetchCityArApi;


/***/ }),

/***/ 2009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ useGetCityEnQuery),
/* harmony export */   "o": () => (/* binding */ FetchCityEnApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchCityEnApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "CityEnData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/Region/"
    }),
    endpoints: (builder)=>({
            getCityEn: builder.query({
                query: ({ Country , Region  })=>`/City/${Country}/${Region}`
            })
        })
});
const { useGetCityEnQuery  } = FetchCityEnApi;


/***/ }),

/***/ 90:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ FetchCountryArApi),
/* harmony export */   "Q": () => (/* binding */ useGetCountryArQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchCountryArApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "CountryArData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/ProgAR/"
    }),
    endpoints: (builder)=>({
            getCountryAr: builder.query({
                query: ()=>"getCountryAR"
            })
        })
});
const { useGetCountryArQuery  } = FetchCountryArApi;


/***/ }),

/***/ 7356:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ useGetCountryEnQuery),
/* harmony export */   "w": () => (/* binding */ FetchCountryEnApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchCountryEnApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "CountryData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/Region/"
    }),
    endpoints: (builder)=>({
            getCountryEn: builder.query({
                query: ()=>"Country"
            })
        })
});
const { useGetCountryEnQuery  } = FetchCountryEnApi;


/***/ }),

/***/ 8808:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ useGetTourTypeQuery),
/* harmony export */   "V": () => (/* binding */ FetchTourTypeApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchTourTypeApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "TourTypeData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/programes/"
    }),
    endpoints: (builder)=>({
            getTourType: builder.query({
                query: ()=>"tour_type"
            })
        })
});
const { useGetTourTypeQuery  } = FetchTourTypeApi;


/***/ }),

/***/ 9613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ FetchTourTypeArApi),
/* harmony export */   "X": () => (/* binding */ useGetTourTypeArQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchTourTypeArApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "TourTypeArData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords/invoice/programes/"
    }),
    endpoints: (builder)=>({
            getTourTypeAr: builder.query({
                query: ()=>"tour_typeAR"
            })
        })
});
const { useGetTourTypeArQuery  } = FetchTourTypeArApi;


/***/ })

};
;