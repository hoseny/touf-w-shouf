"use strict";
exports.id = 6010;
exports.ids = [6010];
exports.modules = {

/***/ 6010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5766);
/* harmony import */ var _mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Signpost__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8884);
/* harmony import */ var _mui_icons_material_Signpost__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Signpost__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_8__);
// import FavoriteIcon from '@mui/icons-material/Favorite';
// import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
// import SignpostIcon from '@mui/icons-material/Signpost';
// import Button from '@mui/material/Button';
// import Typography from '@mui/material/Typography';
// import IconButton from '@mui/material/IconButton';
// import Stack from '@mui/material/Stack';
// import React ,{FunctionComponent} from 'react'      
// import { useTranslation } from 'react-i18next';      
// interface Props {}
// const WatchVideoAndMap :FunctionComponent<Props> = () => {
//     const {t} = useTranslation()      
//   return (
//     <Stack
//     direction="row"
//     justifyContent="start"
//     alignItems="center"
//     spacing={5}
//     sx={{ mb: 3 }}
//   >
//     <Button variant="text" sx={{ padding: 0 }}>
//       <IconButton color="primary" sx={{ boxShadow: 1, mr: 2 }}>
//         <FavoriteIcon />
//       </IconButton>
//       <Typography variant="body1" sx={{ color: 'body.main' }}>
//         {t('Add to Wishlist')}
//       </Typography>
//     </Button>
//     <Button variant="text" sx={{ padding: 0 }}>
//       <IconButton color="primary" sx={{ boxShadow: 1, mr: 2 }}>
//         <PlayArrowRoundedIcon />
//       </IconButton>
//       <Typography variant="body1" sx={{ color: 'body.main' }}>
//         {t('Watch Video')}
//       </Typography>
//     </Button>
//     <Button variant="text" sx={{ padding: 0 }}>
//       <IconButton color="primary" sx={{ boxShadow: 1, mr: 2 }}>
//         <SignpostIcon />
//       </IconButton>
//       <Typography variant="body1" sx={{ color: 'body.main' }}>
//         {t('Map')}
//       </Typography>
//     </Button>
//   </Stack>
// )
// };
// export default WatchVideoAndMap









const WatchVideoAndMap = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6___default()), {
        direction: "row",
        justifyContent: "start",
        alignItems: "center",
        spacing: 5,
        sx: {
            mb: 3
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    cursor: "pointer"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default()), {
                        color: "primary",
                        sx: {
                            boxShadow: 1,
                            mr: 2
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                        variant: "body1",
                        sx: {
                            color: "body.main"
                        },
                        children: t("Add to Wishlist")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    cursor: "pointer"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default()), {
                        color: "primary",
                        sx: {
                            boxShadow: 1,
                            mr: 2
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PlayArrowRounded__WEBPACK_IMPORTED_MODULE_2___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                        variant: "body1",
                        sx: {
                            color: "body.main"
                        },
                        children: t("Watch Video")
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    cursor: "pointer"
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_5___default()), {
                        color: "primary",
                        sx: {
                            boxShadow: 1,
                            mr: 2
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Signpost__WEBPACK_IMPORTED_MODULE_3___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                        variant: "body1",
                        sx: {
                            color: "body.main"
                        },
                        children: t("Map")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WatchVideoAndMap);


/***/ })

};
;