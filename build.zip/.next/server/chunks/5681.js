"use strict";
exports.id = 5681;
exports.ids = [5681];
exports.modules = {

/***/ 4504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ useGetInvoiceQuery),
/* harmony export */   "Y": () => (/* binding */ FetchInvoiceById)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchInvoiceById = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "InvoiceData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: "https://app.misrtravelco.net:4444/ords"
    }),
    endpoints: (builder)=>({
            getInvoice: builder.query({
                query: ({ id  })=>`/invoice/v1/inv/${id}`
            })
        })
});
const { useGetInvoiceQuery  } = FetchInvoiceById;


/***/ }),

/***/ 2232:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ FetchUnPaidReservation),
/* harmony export */   "P": () => (/* binding */ useGetUnPaidReservationQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchUnPaidReservation = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "UnPaidReservationData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `https://app.misrtravelco.net:4444/ords/invoice/public/`
    }),
    endpoints: (builder)=>({
            getUnPaidReservation: builder.query({
                query: (id)=>`getReservation?CustomerID=${id}`
            })
        })
});
const { useGetUnPaidReservationQuery  } = FetchUnPaidReservation;


/***/ })

};
;