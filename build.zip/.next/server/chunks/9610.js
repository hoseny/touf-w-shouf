"use strict";
exports.id = 9610;
exports.ids = [9610];
exports.modules = {

/***/ 9610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AuthLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Container"
var Container_ = __webpack_require__(4475);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(5612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./assets/images/bgAuth.jpg
/* harmony default export */ const bgAuth = ({"src":"/_next/static/media/bgAuth.e41c2ca4.jpg","height":1192,"width":2732,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAgT/2gAMAwEAAhADEAAAAIYGn//EABsQAAEEAwAAAAAAAAAAAAAAAAIAAwQFAXKy/9oACAEBAAE/AAvLeFByDE1wRIdul//EABsRAAIBBQAAAAAAAAAAAAAAAAECAAMREiJB/9oACAECAQE/AKaI2d1B26J//8QAGhEAAgIDAAAAAAAAAAAAAAAAAQIAAxEiwf/aAAgBAwEBPwC13VKcMRp2f//Z"});
;// CONCATENATED MODULE: ./components/AuthLayout/index.tsx








const bgStyle = {
    height: "100%",
    width: "100%",
    backgroundImage: `url('${bgAuth.src}')`,
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
    py: 5.4
};
const Index = ({ children  })=>{
    const { t  } = (0,external_react_i18next_.useTranslation)();
    return /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
        sx: bgStyle,
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "lg",
            sx: {
                height: "100%"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                container: true,
                justifyContent: "space-between",
                alignItems: "center",
                spacing: 6,
                sx: {
                    height: "100%",
                    mt: "unset",
                    flexDirection: {
                        xs: "column",
                        sm: "column",
                        md: "row"
                    }
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 12,
                        md: 6.5,
                        sx: {
                            color: "body.light",
                            textAlign: {
                                xs: "center",
                                md: "left"
                            },
                            mb: {
                                xs: 4,
                                sm: 4,
                                md: 0
                            }
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h2",
                                children: t("Creating an account is great for you!")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h4",
                                sx: {
                                    mt: 2,
                                    fontWeight: 500
                                },
                                children: t("Get access to exclusive deals, save travellers’ details for quicker bookings and manage your upcoming bookings with ease!")
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 12,
                        md: 5,
                        children: children
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const AuthLayout = (Index);


/***/ })

};
;