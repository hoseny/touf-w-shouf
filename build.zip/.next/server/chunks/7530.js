"use strict";
exports.id = 7530;
exports.ids = [7530];
exports.modules = {

/***/ 7530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_6__);







const ReservationItem = ({ customerName , tripDate , reservationNo , PayMentStatus , totalPayment , Currany , PROG_YEAR , ProgramName , IMG_Path , priority =false ,  })=>{
    const labelStyle = {
        color: "#E07026"
    };
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            height: "100%"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            style: {
                height: "100%"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                style: {
                    height: "100%"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-md-12 card reservation-card p-3",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        style: {
                            height: "100%"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-12 col-lg-6",
                                style: {
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "reservation-img-box",
                                    style: {
                                        width: "100%",
                                        height: "100%",
                                        position: "relative"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        src: IMG_Path,
                                        alt: "banner",
                                        layout: "fill",
                                        objectFit: "cover",
                                        style: {
                                            borderRadius: "10px"
                                        }
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-12 col-lg-6 card-body",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Customer Name"),
                                                    " : "
                                                ]
                                            }),
                                            customerName
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Program Name"),
                                                    " : "
                                                ]
                                            }),
                                            ProgramName
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Program Year"),
                                                    " : "
                                                ]
                                            }),
                                            PROG_YEAR
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Trip Date"),
                                                    " : "
                                                ]
                                            }),
                                            new Date(tripDate).toLocaleDateString("en-GB")
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Reservation No"),
                                                    " : "
                                                ]
                                            }),
                                            reservationNo
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Total Price"),
                                                    " : "
                                                ]
                                            }),
                                            totalPayment,
                                            " ",
                                            Currany
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        variant: "body1",
                                        color: PayMentStatus === "Unpaid" ? "error" : "success",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                style: labelStyle,
                                                children: [
                                                    t("Status"),
                                                    " : "
                                                ]
                                            }),
                                            t(PayMentStatus === "Unpaid" ? "Pre invoice" : PayMentStatus === "Paid" ? "Invoice" : PayMentStatus)
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        direction: "row",
                                        spacing: 2,
                                        className: "mt-3 d-flex flex-wrap",
                                        children: [
                                            PayMentStatus !== "Paid" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                className: "m-1",
                                                size: "small",
                                                variant: "contained",
                                                color: "primary",
                                                children: t("Edit")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                className: "m-1",
                                                size: "small",
                                                variant: "contained",
                                                color: "secondary",
                                                children: t(PayMentStatus === "Paid" ? "Print Invoice" : PayMentStatus === "Unpaid" ? "Print Pre Invoice" : "Print")
                                            }),
                                            PayMentStatus !== "Paid" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                className: "m-1",
                                                size: "small",
                                                variant: "outlined",
                                                color: "error",
                                                children: t("Cancel")
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReservationItem); // import React, { FunctionComponent, useState } from 'react';
 // import Typography from '@mui/material/Typography';
 // import Button from '@mui/material/Button';
 // import Stack from '@mui/material/Stack';
 // import Image from 'next/image';
 // import { useTranslation } from 'react-i18next';
 // import Dialog from '@mui/material/Dialog';
 // import DialogActions from '@mui/material/DialogActions';
 // import DialogContent from '@mui/material/DialogContent';
 // import DialogTitle from '@mui/material/DialogTitle';
 // interface Props {
 //     customerName: string;
 //     tripDate: string;
 //     reservationNo: number;
 //     PayMentStatus: string;
 //     totalPayment: string;
 //     Currany: string;
 //     ProgramName: string;
 //     IMG_Path: string;
 //     PROG_YEAR: number;
 //     priority?: boolean;
 // }
 // const ReservationItem: FunctionComponent<Props> = ({
 //     customerName,
 //     tripDate,
 //     reservationNo,
 //     PayMentStatus,
 //     totalPayment,
 //     Currany,
 //     PROG_YEAR,
 //     ProgramName,
 //     IMG_Path,
 //     priority = false,
 // }) => {
 //     const labelStyle = {
 //         color: '#E07026',
 //     };
 //     const { t } = useTranslation();
 //     const [openDialog, setOpenDialog] = useState(false);
 //     const handleDialogOpen = () => setOpenDialog(true);
 //     const handleDialogClose = () => setOpenDialog(false);
 //     return (
 //         <div style={{ height: '100%' }}>
 //             <div className="container" style={{ height: '100%' }}>
 //                 <div className="row" style={{ height: '100%' }}>
 //                     <div className="col-md-12 card reservation-card p-3">
 //                         <div className="row" style={{ height: '100%' }}>
 //                             <div
 //                                 className="col-12 col-lg-6"
 //                                 style={{
 //                                     display: 'flex',
 //                                     alignItems: 'center',
 //                                     justifyContent: 'center',
 //                                 }}
 //                             >
 //                                 <div
 //                                     className="reservation-img-box"
 //                                     style={{ width: '100%', height: '100%', position: 'relative' }}
 //                                 >
 //                                     <Image
 //                                         src={IMG_Path}
 //                                         alt="banner"
 //                                         layout="fill"
 //                                         objectFit="cover"
 //                                         style={{ borderRadius: '10px' }}
 //                                     />
 //                                 </div>
 //                             </div>
 //                             <div className="col-12 col-lg-6 card-body">
 //                                 <Typography variant="body1">
 //                                     <span style={labelStyle}>{t('Customer Name')} : </span>
 //                                     {customerName}
 //                                 </Typography>
 //                                 <Typography variant="body1">
 //                                     <span style={labelStyle}>{t('Program Name')} : </span>
 //                                     {ProgramName}
 //                                 </Typography>
 //                                 <Typography variant="body1">
 //                                     <span style={labelStyle}>{t('Program Year')} : </span>
 //                                     {PROG_YEAR}
 //                                 </Typography>
 //                                 <Typography variant="body1">
 //                                     <span style={labelStyle}>{t('Trip Date')} : </span>
 //                                     {new Date(tripDate).toLocaleDateString('en-GB')}
 //                                 </Typography>
 //                                 <Typography variant="body1">
 //                                     <span style={labelStyle}>{t('Reservation No')} : </span>
 //                                     {reservationNo}
 //                                 </Typography>
 //                                 <Typography variant="body1">
 //                                     <span style={labelStyle}>{t('Total Price')} : </span>
 //                                     {totalPayment} {Currany}
 //                                 </Typography>
 //                                 <Typography
 //                                     variant="body1"
 //                                     color={PayMentStatus === 'Unpaid' ? 'error' : 'success'}
 //                                 >
 //                                     <span style={labelStyle}>{t('Status')} : </span>
 //                                     {t(
 //                                         PayMentStatus === 'Unpaid'
 //                                             ? 'Pre invoice'
 //                                             : PayMentStatus === 'Paid'
 //                                             ? 'Invoice'
 //                                             : PayMentStatus
 //                                     )}
 //                                 </Typography>
 //                                 <Stack
 //                                     direction="row"
 //                                     spacing={2}
 //                                     className="mt-3 d-flex flex-wrap"
 //                                 >
 //                                     {PayMentStatus !== 'Paid' && (
 //                                         <Button
 //                                             className="m-1"
 //                                             size="small"
 //                                             variant="contained"
 //                                             color="primary"
 //                                         >
 //                                             {t('Edit')}
 //                                         </Button>
 //                                     )}
 //                                     <Button
 //                                         className="m-1"
 //                                         size="small"
 //                                         variant="contained"
 //                                         color="secondary"
 //                                         onClick={handleDialogOpen}
 //                                     >
 //                                         {t(
 //                                             PayMentStatus === 'Paid'
 //                                                 ? 'Print Invoice'
 //                                                 : PayMentStatus === 'Unpaid'
 //                                                 ? 'Print Pre Invoice'
 //                                                 : 'Print'
 //                                         )}
 //                                     </Button>
 //                                     {PayMentStatus !== 'Paid' && (
 //                                         <Button
 //                                             className="m-1"
 //                                             size="small"
 //                                             variant="outlined"
 //                                             color="error"
 //                                         >
 //                                             {t('Cancel')}
 //                                         </Button>
 //                                     )}
 //                                 </Stack>
 //                             </div>
 //                         </div>
 //                     </div>
 //                 </div>
 //             </div>
 //             {/* Dialog for displaying the data */}
 //             <Dialog open={openDialog} onClose={handleDialogClose}>
 //                 <DialogTitle>{t('Reservation Details')}</DialogTitle>
 //                 <DialogContent>
 //                     <Typography variant="body1">
 //                         {t('Customer Name')}: {customerName}
 //                     </Typography>
 //                     <Typography variant="body1">
 //                         {t('Program Name')}: {ProgramName}
 //                     </Typography>
 //                     <Typography variant="body1">
 //                         {t('Program Year')}: {PROG_YEAR}
 //                     </Typography>
 //                     <Typography variant="body1">
 //                         {t('Trip Date')}: {new Date(tripDate).toLocaleDateString('en-GB')}
 //                     </Typography>
 //                     <Typography variant="body1">
 //                         {t('Reservation No')}: {reservationNo}
 //                     </Typography>
 //                     <Typography variant="body1">
 //                         {t('Total Price')}: {totalPayment} {Currany}
 //                     </Typography>
 //                 </DialogContent>
 //                 <DialogActions>
 //                     <Button onClick={handleDialogClose} color="primary">
 //                         {t('Close')}
 //                     </Button>
 //                 </DialogActions>
 //             </Dialog>
 //         </div>
 //     );
 // };
 // export default ReservationItem;


/***/ })

};
;