"use strict";
exports.id = 3603;
exports.ids = [3603];
exports.modules = {

/***/ 5872:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ FetchPolicyApi),
/* harmony export */   "q": () => (/* binding */ useGetPolicyQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPolicyApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PolicyData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getPolicy: builder.query({
                query: ({ code , programyear  })=>`/programpolicy/${code}/${programyear}/Cancel`
            })
        })
});
const { useGetPolicyQuery  } = FetchPolicyApi;


/***/ }),

/***/ 2688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useGetIncludingQuery),
/* harmony export */   "V": () => (/* binding */ FetchTourIncludingApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchTourIncludingApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "IncludingData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getIncluding: builder.query({
                query: ({ code , programyear  })=>`/tourincluding/${code}/${programyear}`
            })
        })
});
const { useGetIncludingQuery  } = FetchTourIncludingApi;


/***/ }),

/***/ 5294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ useGetIncludingArQuery),
/* harmony export */   "s": () => (/* binding */ FetchTourIncludingArApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchTourIncludingArApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "IncludingArData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getIncludingAr: builder.query({
                query: ({ code , programyear  })=>`/TourIncludingAR/${code}/${programyear}`
            })
        })
});
const { useGetIncludingArQuery  } = FetchTourIncludingArApi;


/***/ })

};
;