exports.id = 9996;
exports.ids = [9996];
exports.modules = {

/***/ 9996:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2311);
/* harmony import */ var _mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3103);
/* harmony import */ var _mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_InsertInvitationRounded__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4878);
/* harmony import */ var _mui_icons_material_InsertInvitationRounded__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_InsertInvitationRounded__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_Filter_FetchCountryEnApi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7356);
/* harmony import */ var _store_Filter_FetchTourTypeApi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8808);
/* harmony import */ var _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8173);
/* harmony import */ var _store_Filter_FetchCountryArApi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(90);
/* harmony import */ var _store_Filter_FetchTourTypeArApi__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9613);
/* harmony import */ var _store_Filter_FetchCityEnApi__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2009);
/* harmony import */ var _store_Filter_FetchCityArApi__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8631);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9648);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(983);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_datepicker__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5994);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(8248);
/* harmony import */ var _mui_material_Modal__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9564);
/* harmony import */ var _mui_material_Modal__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Modal__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _components_Loading_Loading__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(905);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(4317);
/* harmony import */ var _mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_27__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_16__, date_fns__WEBPACK_IMPORTED_MODULE_19__]);
([axios__WEBPACK_IMPORTED_MODULE_16__, date_fns__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





























const Outings = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_25__.useRouter)();
    const language = _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_11__/* .ClientStorage.get */ .j.get("language") || "en";
    const langCode = language === "en" ? 1 : 2;
    const { 0: error , 1: setError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: selectedCountry , 1: setSelectedCountry  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: citiesData , 1: setCitiesData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: selectedCity , 1: setSelectedCity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: selectedDate , 1: setSelectedDate  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: searchResults , 1: setSearchResults  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: openModal , 1: setOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: selectedTripType , 1: setSelectedTripType  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    // Countries
    const { data: CountriesEn , isError: isErrorEn  } = (0,_store_Filter_FetchCountryEnApi__WEBPACK_IMPORTED_MODULE_9__/* .useGetCountryEnQuery */ ._)({});
    const { data: CountriesAr , isError: isErrorAr  } = (0,_store_Filter_FetchCountryArApi__WEBPACK_IMPORTED_MODULE_12__/* .useGetCountryArQuery */ .Q)({});
    const CountriesData = language === "ar" ? CountriesAr?.Countries || [] : CountriesEn?.Countries || [];
    // Fetch Cities based on selected country and region
    const { data: CityEn  } = (0,_store_Filter_FetchCityEnApi__WEBPACK_IMPORTED_MODULE_14__/* .useGetCityEnQuery */ .K)({
        Country: selectedCountry?.COUNTRY_CODE,
        Region: selectedCountry?.REGION_CODE
    });
    const { data: CityAr  } = (0,_store_Filter_FetchCityArApi__WEBPACK_IMPORTED_MODULE_15__/* .useGetCityArQuery */ .d)({
        Country: selectedCountry?.COUNTRY_CODE,
        Region: selectedCountry?.REGION_CODE
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (selectedCountry) {
            const cityData = language === "ar" ? CityAr?.Countries || [] : CityEn?.Countries || [];
            setCitiesData(cityData);
        } else {
            setCitiesData([]);
        }
    }, [
        selectedCountry,
        CityEn,
        CityAr,
        language
    ]);
    // TourType
    const { data: TourType , isError: isTourTypeErrorEn  } = (0,_store_Filter_FetchTourTypeApi__WEBPACK_IMPORTED_MODULE_10__/* .useGetTourTypeQuery */ .D)({});
    const { data: TourTypeAr , isError: isTourTypeErrorAr  } = (0,_store_Filter_FetchTourTypeArApi__WEBPACK_IMPORTED_MODULE_13__/* .useGetTourTypeArQuery */ .X)({});
    const TourTypeData = language === "ar" ? TourTypeAr?.items || [] : TourType?.items || [];
    if (isErrorEn || isErrorAr) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Error loading countries data."
        });
    }
    if (isTourTypeErrorEn || isTourTypeErrorAr) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Error loading tour type data."
        });
    }
    const handleSearch = async ()=>{
        if (!selectedDate) {
            setError(t("Please select a date"));
            return;
        }
        if (selectedCountry && !selectedCity) {
            setError(t("Please select a city"));
            return;
        }
        const apiUrl = language === "ar" ? "https://app.misrtravelco.net:4444/ords/invoice/ProgAR/SearchAR" : "https://app.misrtravelco.net:4444/ords/invoice/programes/search";
        const queryParams = {
            City: String(selectedCity?.CITY_CODE || ""),
            Country: String(selectedCountry?.COUNTRY_CODE || ""),
            T_Type: String(selectedTripType?.id || ""),
            T_Date: selectedDate ? (0,date_fns__WEBPACK_IMPORTED_MODULE_19__.format)(selectedDate, "dd/MM/yyyy") : ""
        };
        const queryString = new URLSearchParams(queryParams).toString();
        try {
            setLoading(true);
            const response = await axios__WEBPACK_IMPORTED_MODULE_16__["default"].get(`${apiUrl}?${queryString}`);
            setSearchResults(response.data.Trips || []);
            setError(null);
            setOpenModal(true);
        } catch (error) {
            setError("Failed to fetch search results. Please try again.");
            console.error("Error fetching search results:", error);
        } finally{
            setLoading(false);
        }
    };
    const handleDateChange = (date)=>{
        if (date) {
            setSelectedDate(date);
            console.log("T_Date:", (0,date_fns__WEBPACK_IMPORTED_MODULE_19__.format)(date, "dd/MM/yyyy"));
        }
    };
    const clearDate = ()=>{
        setSelectedDate(null);
    };
    const handleCloseModal = ()=>{
        setOpenModal(false);
    };
    const labelStyle = {
        color: "#E07026"
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
        container: true,
        justifyContent: "center",
        alignItems: "end",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                item: true,
                xs: 6,
                md: 2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_2___default()), {
                    id: "country",
                    options: (CountriesData || []).map((n)=>({
                            label: n.COUNTRY_NAME || "Unknown",
                            COUNTRY_CODE: n.COUNTRY_CODE,
                            REGION_CODE: n.REGION_CODE
                        })),
                    autoHighlight: true,
                    onChange: (_, value)=>setSelectedCountry(value ? {
                            COUNTRY_CODE: value.COUNTRY_CODE,
                            REGION_CODE: value.REGION_CODE
                        } : null),
                    sx: {
                        backgroundColor: "body.light",
                        borderRadius: "0",
                        color: "main.lightGray",
                        width: "100%",
                        "& .MuiInputBase-root": {
                            borderRadius: "0"
                        }
                    },
                    getOptionLabel: (option)=>option.label,
                    renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default()), {
                            ...params,
                            placeholder: t("Countries"),
                            inputProps: {
                                ...params.inputProps
                            }
                        }),
                    renderOption: (props, option)=>/*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)("li", {
                            ...props,
                            key: option.COUNTRY_CODE
                        }, option.label)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                item: true,
                xs: 6,
                md: 2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_2___default()), {
                    id: "city",
                    options: (citiesData || []).map((n)=>({
                            label: n.CITY_NAME || "Unknown",
                            CITY_CODE: n.CITY_CODE
                        })),
                    autoHighlight: true,
                    onChange: (_, value)=>setSelectedCity(value ? {
                            CITY_CODE: value.CITY_CODE,
                            CITY_NAME: value.label
                        } : null),
                    disabled: !selectedCountry,
                    sx: {
                        backgroundColor: "body.light",
                        borderRadius: "0",
                        color: "main.lightGray",
                        width: "100%",
                        "& .MuiInputBase-root": {
                            borderRadius: "0"
                        }
                    },
                    getOptionLabel: (option)=>option.label,
                    renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default()), {
                            ...params,
                            placeholder: t("City"),
                            inputProps: {
                                ...params.inputProps
                            }
                        }),
                    renderOption: (props, option)=>/*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)("li", {
                            ...props,
                            key: option.CITY_CODE
                        }, option.label)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                item: true,
                xs: 6,
                md: 2.4,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_2___default()), {
                    id: "tripType",
                    options: TourTypeData.map((type)=>({
                            id: type.tour_type_code,
                            name: language === "ar" ? type.tour_type_desc_ara : type.tour_type_desc
                        })),
                    autoHighlight: true,
                    getOptionLabel: (option)=>option.name || "",
                    onChange: (_, value)=>setSelectedTripType(value || null),
                    value: selectedTripType,
                    sx: {
                        backgroundColor: "body.light",
                        borderRadius: "0",
                        color: "main.lightGray",
                        width: "100%",
                        "& .MuiInputBase-root": {
                            borderRadius: "0"
                        }
                    },
                    renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default()), {
                            ...params,
                            placeholder: t("Trip type"),
                            inputProps: {
                                ...params.inputProps
                            }
                        }),
                    renderOption: (props, option)=>/*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createElement)("li", {
                            ...props,
                            key: option.id
                        }, option.name)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                item: true,
                xs: 6,
                md: 2.4,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_datepicker__WEBPACK_IMPORTED_MODULE_17___default()), {
                    selected: selectedDate,
                    onChange: handleDateChange,
                    dateFormat: "dd/MM/yyyy",
                    placeholderText: "Pick a date",
                    customInput: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_6___default()), {
                        fullWidth: true,
                        value: selectedDate ? selectedDate.toLocaleDateString("en-GB") : "",
                        sx: {
                            backgroundColor: "body.light",
                            borderRadius: "0",
                            color: "main.lightGray"
                        },
                        InputProps: {
                            startAdornment: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_5___default()), {
                                position: "start",
                                sx: {
                                    color: "main.lightGray"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_InsertInvitationRounded__WEBPACK_IMPORTED_MODULE_8___default()), {})
                            }),
                            endAdornment: selectedDate && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_InputAdornment__WEBPACK_IMPORTED_MODULE_5___default()), {
                                position: "end",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_27___default()), {
                                    onClick: clearDate,
                                    size: "small",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CloseRounded__WEBPACK_IMPORTED_MODULE_26___default()), {})
                                })
                            })
                        }
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_4___default()), {
                item: true,
                xs: 6,
                md: 2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                    type: "button",
                    variant: "contained",
                    size: "large",
                    fullWidth: true,
                    sx: {
                        borderRadius: "0 5px 5px 0",
                        py: 1.9,
                        boxShadow: 0
                    },
                    onClick: handleSearch,
                    disabled: loading,
                    children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading_Loading__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {}) // عرض اللودينج
                     : t("Search") // النص الافتراضي
                })
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                variant: "body2",
                color: "error",
                style: {
                    marginTop: "10px",
                    backgroundColor: "white",
                    padding: 10
                },
                children: error
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Modal__WEBPACK_IMPORTED_MODULE_20___default()), {
                open: openModal,
                onClose: handleCloseModal,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_21___default()), {
                    sx: {
                        width: "60%",
                        margin: "auto",
                        marginTop: "100px",
                        backgroundColor: "white",
                        padding: 3,
                        borderRadius: 2,
                        "@media (max-width: 600px)": {
                            width: "95%",
                            height: "auto"
                        },
                        maxHeight: "80vh",
                        overflowY: "auto",
                        "&::-webkit-scrollbar": {
                            width: "4px"
                        },
                        "&::-webkit-scrollbar-thumb": {
                            backgroundColor: "#e97c34",
                            borderRadius: "10px"
                        },
                        "&::-webkit-scrollbar-thumb:hover": {
                            backgroundColor: "#555"
                        }
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                            variant: "h6",
                            gutterBottom: true,
                            children: [
                                t("Search Results"),
                                " ",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    style: {
                                        color: "#e97c34"
                                    },
                                    children: [
                                        "(",
                                        searchResults.length,
                                        ")"
                                    ]
                                })
                            ]
                        }),
                        loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                textAlign: "center",
                                marginTop: "20px"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading_Loading__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {})
                        }) : error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                color: "red"
                            },
                            children: error
                        }) : searchResults.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: searchResults.map((result, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    style: {
                                        height: "100%"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "container",
                                        style: {
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "row",
                                            style: {
                                                height: "100%"
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "col-md-12 card reservation-card p-3 mb-3",
                                                style: {
                                                    cursor: "pointer"
                                                },
                                                onClick: ()=>router.push(`/productDetails/${result.PROG__CODE}/${result.prog_year}/${langCode}`),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "row",
                                                    style: {
                                                        height: "100%"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "col-12 col-lg-6",
                                                            style: {
                                                                display: "flex",
                                                                alignItems: "center",
                                                                justifyContent: "center"
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "reservation-img-box",
                                                                style: {
                                                                    width: "100%",
                                                                    height: "100%",
                                                                    position: "relative"
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_23___default()), {
                                                                    src: result.PathImage,
                                                                    alt: "banner",
                                                                    layout: "fill",
                                                                    objectFit: "cover",
                                                                    style: {
                                                                        borderRadius: "10px"
                                                                    }
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "col-12 col-lg-6 card-body",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("Program Name"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.PROG__NAME
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("Country"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.COUNTRY_NAME
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("City"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.City
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("Program Year"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.prog_year
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("Trip Date from"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.Date_From
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("Trip Date to"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.Date_to
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_22___default()), {
                                                                    variant: "body1",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            style: labelStyle,
                                                                            children: [
                                                                                t("Start Price"),
                                                                                " :",
                                                                                " "
                                                                            ]
                                                                        }),
                                                                        result.start_price
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                }, index))
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: t("No results found.")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                            onClick: handleCloseModal,
                            variant: "contained",
                            sx: {
                                marginTop: 2
                            },
                            children: t("Close")
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Outings);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5994:
/***/ (() => {



/***/ })

};
;