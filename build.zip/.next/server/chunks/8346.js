"use strict";
exports.id = 8346;
exports.ids = [8346];
exports.modules = {

/***/ 4499:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useGetExtraQuery),
/* harmony export */   "e": () => (/* binding */ FetchExtraApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchExtraApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "ExtraData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getExtra: builder.query({
                query: ({ code , programyear  })=>`/ExtraProgram/${code}/${programyear}`
            })
        })
});
const { useGetExtraQuery  } = FetchExtraApi;


/***/ }),

/***/ 5295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ FetchGroupPriceApi),
/* harmony export */   "b": () => (/* binding */ useGetGroupPriceQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchGroupPriceApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "GroupPrice",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getGroupPrice: builder.query({
                query: ({ code , programyear , groupNo  })=>`/GroupPrice/${code}/${programyear}/${groupNo}`
            })
        })
});
const { useGetGroupPriceQuery  } = FetchGroupPriceApi;


/***/ }),

/***/ 7921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ FetchProgramGroupsApi),
/* harmony export */   "v": () => (/* binding */ useGetProgramGroupQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchProgramGroupsApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "ProgramGroups",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getProgramGroup: builder.query({
                query: ({ code , programyear  })=>`/ProgramGroups/${code}/${programyear}`
            })
        })
});
const { useGetProgramGroupQuery  } = FetchProgramGroupsApi;


/***/ }),

/***/ 6885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ AddExtraApi),
/* harmony export */   "R": () => (/* binding */ useAddExtraMutation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);
// import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
// export const AddExtraApi = createApi({
//     reducerPath: 'AddExtra',
//     tagTypes: ['addExtra'],
//     baseQuery: fetchBaseQuery({
//         baseUrl: process.env.NEXT_PUBLIC_API_URL,
//     }),
//     endpoints: builder => ({
//         addExtra: builder.mutation({
//             query: ({ code, year, ...values }) => {
//                 const formData = new FormData();
//                 Object.keys(values).forEach(key => {
//                     formData.append(key, values[key]);
//                 });
//                 return {
//                     url: `/ExtraProgram/${code}/${year}`,
//                     method: 'POST',
//                     body: formData,
//                 };
//             },
//             invalidatesTags: ['addExtra'],
//         }),
//     }),
// });
// export const { useAddExtraMutation } = AddExtraApi;

const AddExtraApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "AddExtra",
    tagTypes: [
        "Extra"
    ],
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            addExtra: builder.mutation({
                query: ({ code , year , ...values })=>({
                        url: `/ExtraProgram/${code}/${year}`,
                        method: "POST",
                        body: values,
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }),
                invalidatesTags: [
                    "Extra"
                ]
            })
        })
});
const { useAddExtraMutation  } = AddExtraApi;


/***/ }),

/***/ 4189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ AddReservationApi),
/* harmony export */   "A": () => (/* binding */ useAddReservationMutation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const AddReservationApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "AddReservation",
    tagTypes: [
        "Reservation"
    ],
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            addReservation: builder.mutation({
                query: (values)=>({
                        url: "/Reservation/",
                        method: "POST",
                        body: values,
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }),
                invalidatesTags: [
                    "Reservation"
                ]
            })
        })
});
const { useAddReservationMutation  } = AddReservationApi;


/***/ }),

/***/ 6485:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ AddReservationDetailsApi),
/* harmony export */   "i": () => (/* binding */ useAddReservationDetailsMutation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const AddReservationDetailsApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "AddReservationDetails",
    tagTypes: [
        "ReservationDetails"
    ],
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            addReservationDetails: builder.mutation({
                query: (values)=>({
                        url: "/DetailsesRev/",
                        method: "POST",
                        body: values,
                        headers: {
                            "Content-Type": "application/json"
                        }
                    }),
                invalidatesTags: [
                    "ReservationDetails"
                ]
            })
        })
});
const { useAddReservationDetailsMutation  } = AddReservationDetailsApi;


/***/ })

};
;