"use strict";
exports.id = 2481;
exports.ids = [2481];
exports.modules = {

/***/ 5721:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ FetchPackagesArApi),
/* harmony export */   "y": () => (/* binding */ useGetPackageArQuery)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPackagesArApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PackageDataAr",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getPackageAr: builder.query({
                query: ()=>"/PackageArabic"
            })
        })
});
const { useGetPackageArQuery  } = FetchPackagesArApi;


/***/ }),

/***/ 1234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ useGetPackageEnQuery),
/* harmony export */   "M": () => (/* binding */ FetchPackagesEnApi)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPackagesEnApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PackageDataEn",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `${"https://app.misrtravelco.net:4444/ords/invoice/programes"}`
    }),
    endpoints: (builder)=>({
            getPackageEn: builder.query({
                query: ()=>"/Packages"
            })
        })
});
const { useGetPackageEnQuery  } = FetchPackagesEnApi;


/***/ }),

/***/ 4366:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G3": () => (/* binding */ getLanguage),
/* harmony export */   "XP": () => (/* binding */ getDir),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "v7": () => (/* binding */ toggleLanguage)
/* harmony export */ });
/* unused harmony exports languageSlice, changeDir */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2021);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_1__]);
i18next__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    dir: "ltr",
    language: "en"
};
const languageSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "language",
    initialState,
    reducers: {
        toggleLanguage: (state, action)=>{
            // eslint-disable-next-line default-case
            state.language = action.payload;
            if (state.language === "ar") {
                document.body.setAttribute("dir", "rtl");
                state.dir = "rtl";
                i18next__WEBPACK_IMPORTED_MODULE_1__["default"].changeLanguage("ar");
            } else if (state.language === "en") {
                document.body.setAttribute("dir", "ltr");
                state.dir = "ltr";
                i18next__WEBPACK_IMPORTED_MODULE_1__["default"].changeLanguage("en");
            } else if (state.language === undefined) {
                document.body.setAttribute("dir", "ltr");
                state.dir = "ltr";
                i18next__WEBPACK_IMPORTED_MODULE_1__["default"].changeLanguage("en");
            }
        },
        onloadSetCurrentLanguage: (state, action)=>{
            state.language = action.payload;
        },
        changeDir: (state)=>{
            state.dir = state.dir === "ltr" ? "rtl" : "ltr";
        },
        changeLanguage: (state)=>{
            state.language = state.language === "en" ? "ar" : "en";
        }
    }
});
const { changeDir , toggleLanguage  } = languageSlice.actions;
const getDir = (state)=>state.language.dir;
const getLanguage = (state)=>state.language.language;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (languageSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;