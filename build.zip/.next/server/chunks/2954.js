"use strict";
exports.id = 2954;
exports.ids = [2954];
exports.modules = {

/***/ 8173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ ClientStorage)
/* harmony export */ });
const ClientStorage = {
    get (key) {
        if (false) {}
        return null;
    },
    set (key, value) {
        if (false) {}
    }
};


/***/ }),

/***/ 2954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4475);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Loading_Loading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(905);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8173);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _Reservation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7530);
/* harmony import */ var _store_Reservation_FetchPaidReservation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7986);










const UnpaidReservation = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const custcode = _hooks_useLocalStroge__WEBPACK_IMPORTED_MODULE_6__/* .ClientStorage.get */ .j.get("custcode");
    const { data , isLoading , error  } = (0,_store_Reservation_FetchPaidReservation__WEBPACK_IMPORTED_MODULE_9__/* .useGetPaidReservationQuery */ .F)(custcode);
    const reservations = data?.CustomerPayment || [];
    if (isLoading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loading_Loading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {
        children: t("Error fetching data")
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Container__WEBPACK_IMPORTED_MODULE_1___default()), {
            maxWidth: "lg",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_2___default()), {
                container: true,
                sx: {
                    my: 4
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_2___default()), {
                    container: true,
                    spacing: 2,
                    children: reservations.map((reservation)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_2___default()), {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Reservation__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                customerName: reservation.CustomerName,
                                IMG_Path: reservation.IMG_Path,
                                tripDate: reservation.DateTrip,
                                reservationNo: reservation.ReservationNo,
                                totalPayment: reservation.TotalPayMent,
                                Currany: reservation.Currany,
                                PROG_YEAR: reservation.PROG_YEAR,
                                ProgramName: reservation.ProgramName,
                                PayMentStatus: reservation.PayMentStatus
                            })
                        }, reservation.ReservationNo))
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UnpaidReservation);


/***/ }),

/***/ 7986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useGetPaidReservationQuery),
/* harmony export */   "U": () => (/* binding */ FetchPaidReservation)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4335);
/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);

const FetchPaidReservation = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({
    reducerPath: "PaidReservationData",
    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({
        baseUrl: `https://app.misrtravelco.net:4444/ords/invoice/public/`
    }),
    endpoints: (builder)=>({
            getPaidReservation: builder.query({
                query: (id)=>`GetPayment?CustomerID=${id}`
            })
        })
});
const { useGetPaidReservationQuery  } = FetchPaidReservation;


/***/ })

};
;