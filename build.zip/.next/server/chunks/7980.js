"use strict";
exports.id = 7980;
exports.ids = [7980];
exports.modules = {

/***/ 7980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_Register_VerifyEmailApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8019);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3590);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_Register_RegisterApi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4868);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_4__]);
react_toastify__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const VerifyHandler = ({ OTP , email , phone , setOtpError , setEmailError , setPhoneError , setIsLoading ,  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const [verifyEmail] = (0,_store_Register_VerifyEmailApi__WEBPACK_IMPORTED_MODULE_3__/* .useVerifyEmailMutation */ .q)();
    const [addUser] = (0,_store_Register_RegisterApi__WEBPACK_IMPORTED_MODULE_9__/* .useAddUserMutation */ .V)();
    const { 0: isResendDisabled , 1: setIsResendDisabled  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: timer , 1: setTimer  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(60);
    const handleVerify = async ()=>{
        let isValid = true;
        if (OTP === "") {
            setOtpError(t("OTP is required"));
            isValid = false;
        } else {
            setOtpError(null);
        }
        if (email === "") {
            setEmailError(t("Email is required"));
            isValid = false;
        } else {
            setEmailError(null);
        }
        if (phone === "") {
            setPhoneError(t("Phone is required"));
            isValid = false;
        } else {
            setPhoneError(null);
        }
        if (!isValid) return;
        setIsLoading(true);
        try {
            const response = await verifyEmail({
                OTP: Number(OTP),
                p_Mail: email,
                TEL: phone
            }).unwrap();
            if (response.OTP === "This Phone already Exist") {
                setPhoneError(t("This phone number already exists. Please use another number."));
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("This phone number already exists!"));
                return;
            }
            if (response.OTP === "OTP is Invalid/Expired") {
                setOtpError(t("The OTP is invalid or has expired. Please request a new one."));
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("The OTP is invalid or has expired!"));
                return;
            }
            if (response.OTP === "This Mail already Exist") {
                setEmailError(t("This email already exists. Please use another email."));
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("This email already exists!"));
                return;
            }
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(t("Email verified successfully!"), {
                className: "toast-orange",
                autoClose: 2000
            });
            if (false) {}
            setTimeout(()=>{
                router.push("/login");
            }, 2000);
        } catch (error) {
            console.error(error);
            setOtpError(t("Verification failed. Please check the OTP."));
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("Verification failed!"));
        } finally{
            setIsLoading(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (timer > 0) {
            const interval = setInterval(()=>{
                setTimer((prevTimer)=>prevTimer - 1);
            }, 1000);
            return ()=>clearInterval(interval);
        } else {
            setIsResendDisabled(false);
        }
    }, [
        timer
    ]);
    const handleResendOTP = async ()=>{
        const storedData = sessionStorage.getItem("addUser");
        if (storedData) {
            const userData = JSON.parse(storedData);
            setIsResendDisabled(true);
            setTimer(60);
            try {
                const response = await addUser({
                    p_Mail: userData.p_Mail,
                    TEL: userData.TEL,
                    CNAME: userData.CNAME,
                    NAT: userData.NAT,
                    C_ADDRESS: userData.C_ADDRESS,
                    C_PASS: userData.C_PASS
                }).unwrap();
                if (response?.item?.[0]?.OTP === "Please Review Your Mail ") {
                    react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(t("OTP resent successfully!"));
                } else {
                    react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("Failed to resend OTP."));
                }
            } catch (error) {
                console.error(error);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("An error occurred while resending the OTP."));
            }
        } else {
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(t("No user data found"));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_8___default()), {
                item: true,
                xs: 12,
                sx: {
                    mt: 4
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default()), {
                    type: "submit",
                    variant: "contained",
                    size: "large",
                    sx: {
                        py: "13px"
                    },
                    fullWidth: true,
                    onClick: handleVerify,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                        variant: "button",
                        children: t("Verify")
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_8___default()), {
                item: true,
                xs: 12,
                sx: {
                    mt: 2
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default()), {
                    type: "button",
                    variant: "contained",
                    size: "large",
                    sx: {
                        py: "13px"
                    },
                    fullWidth: true,
                    onClick: handleResendOTP,
                    disabled: isResendDisabled,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_7___default()), {
                        variant: "button",
                        children: isResendDisabled ? `${t("Resend OTP")} (${timer}s)` : t("Resend OTP")
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerifyHandler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;